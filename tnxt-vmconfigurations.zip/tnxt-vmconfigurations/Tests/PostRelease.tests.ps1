param
(
	[Parameter(Mandatory=$true)]
	[ValidateNotNullOrEmpty()]
	[string] $WorkerMachines,

	[Parameter(Mandatory=$true)]
	[ValidateNotNullOrEmpty()]
	[string] $Username,

	[Parameter(Mandatory=$true)]
	[ValidateNotNullOrEmpty()]
	[string] $Password
)

Describe "VM Configurations are deployed successfully to the worker machines" {
	Context "C:\Configurations folder files are listed" {
        BeforeAll {
            $workers = @($WorkerMachines.Split(",") | ForEach-Object { return $_.Trim() })
            $securePassword = ConvertTo-SecureString -String $Password -AsPlainText -Force
            $credentials = New-Object System.Management.Automation.PSCredential ($Username, $securePassword)

            $randomWorker = $workers[(Get-Random -Maximum $workers.Count)]

            $configurations = Invoke-Command -ScriptBlock {
                Get-ChildItem -Path "C:\Configurations" -Filter "*.ps1" | Select-Object -ExpandProperty Name
            } -ComputerName $randomWorker -Credential $credentials

        }
		It "Should contain the LCMSettings configuration file" {
			$configurations.Contains("LCMSettings.ps1") | Should Be $true
		}
		It "Should contain the BootstrapChoco configuration file" {
			$configurations.Contains("BootstrapChoco.ps1") | Should Be $true
		}
		It "Should contain the DotNet configuration file" {
			$configurations.Contains("DotNet.ps1") | Should Be $true
		}
		It "Should contain the DotNetModules configuration file" {
			$configurations.Contains("DotNetModules.ps1") | Should Be $true
		}
		It "Should contain the SqlSA configuration file" {
			$configurations.Contains("SqlSA.ps1") | Should Be $true
		}
		It "Should contain the SqlSaModules configuration file" {
			$configurations.Contains("SqlSaModules.ps1") | Should Be $true
		}
	}
}