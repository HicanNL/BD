param
(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $WorkloadInstallerAccountCredential,

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [String] $ConfigurationDataPath = "${Env:SystemDrive}\Configurations\Biz",

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [String] $InstallationFile = "BTSInstall.xml"
)

Configuration Biz
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName cMSDTC
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node $AllNodes.NodeName
    {
        WindowsFeature PowerShell-V4
        {
            Ensure = 'Present'
            Name = 'PowerShell'
        }

        WindowsFeature PowerShell-V2Engine
        {
            Ensure = 'Present'
            Name = 'PowerShell-V2'
        }

        WindowsFeature RemoteADAdministrationPowerShellModule
        {
            Ensure = 'Present'
            Name   = 'RSAT-AD-PowerShell'
        }

        WindowsFeature DotNetFramework
        {
            Ensure = 'Present'
            Name = 'NET-Framework-Core'
        }

        WindowsFeature DotNetFramework45
        {
            Ensure = 'Present'
            Name   = 'NET-Framework-45-Core'
        }

        WindowsFeature DotNetFramework45ASPNet
        {
            Ensure = 'Present'
            Name = 'NET-Framework-45-ASPNET'
        }

        WindowsFeature NetFramework
        {
            Ensure = 'Present'
            Name = 'AS-NET-Framework'
        }

        WindowsFeature TCPPortSharing
        {
            Ensure = 'Present'
            Name   = 'AS-TCP-Port-Sharing'
        }

        WindowsFeature WASSupport
        {
            Ensure = 'Present'
            Name = 'AS-WAS-Support'
        }

        WindowsFeature HTTPActivationAS
        {
            Ensure = 'Present'
            Name   = 'AS-HTTP-Activation'
        }

        WindowsFeature HTTPActivationNET
        {
            Ensure = 'Present'
            Name = 'NET-HTTP-Activation'
        }

        WindowsFeature TCPActivation
        {
            Ensure = 'Present'
            Name   = 'AS-TCP-Activation'
        }

        WindowsFeature NETWCFHTTPActivation45
        {
            Ensure = 'Present'
            Name   = 'NET-WCF-HTTP-Activation45'
        }

        WindowsFeature NETWCFTCPActivation45
        {
            Ensure = 'Present'
            Name   = 'NET-WCF-TCP-Activation45'
        }

        WindowsFeature NETWCFTCPPortSharing45
        {
            Ensure = 'Present'
            Name   = 'NET-WCF-TCP-PortSharing45'
        }

        UserRightsAssignment LogonAsAservice
        {
            Policy               = "log_on_as_a_service"
            Identity             = @(
                                       "$($Node.NetBIOSDomainName)\RESA-AD-LogOnAsAService",
                                       "NT SERVICE\ALL SERVICES",
                                       "$($Node.NetBIOSDomainName)\Workload-ServiceAccounts"
                                   )
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
        }

        UserRightsAssignment LogonAsABatchJob
        {
            Policy               = "log_on_as_a_batch_job"
            Identity             = @(
                                       "$($Node.NetBIOSDomainName)\RESA-AD-LogOnAsBatchJob",
                                       "NT SERVICE\ALL SERVICES",
                                       "$($Node.NetBIOSDomainName)\Workload-ServiceAccounts",
                                       "$($Node.NetBIOSDomainName)\Administrator"
                                   )
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
        }

        Registry FIPS_Disable
        {
            Ensure      = 'Present'
            Key         = 'HKLM:\System\CurrentControlSet\Control\Lsa\FipsAlgorithmPolicy'
            ValueName   = 'Enabled'
            ValueData   = '0'
            ValueType   = 'Dword'
        }

        cMSDTC Sql_MsDtc
        {
            Ensure                            = 'Present'
            Name                              = 'Local'
            InboundTransactionsEnabled        = 1
            OutboundTransactionsEnabled       = 1
            RemoteClientAccessEnabled         = 1
            RemoteAdministrationAccessEnabled = 1
            AuthenticationLevel               = 'Mutual'
            LUTransactionsEnabled             = 1
            XATransactionsEnabled             = 0
        }

        Package VCRedistx86_Install
        {
            Ensure                            = "Present"
            Path                              = "$($Node.ConfigurationDataPath)\vcredist_x86.exe"
            Arguments                         = "/q /norestart /log ${Env:\windir}\logs\vcredist_x86.log"
            Name                              = "Microsoft Visual C++ 2010 x86 Redistributable Setup"
            ProductId                         = "F0C3E5D1-1ADE-321E-8167-68EF0DE699A5"
        }

        Package VCRedistx64_Install
        {
            Ensure                            = "Present"
            Path                              = "$($Node.ConfigurationDataPath)\vcredist_x64.exe"
            Arguments                         = "/q /norestart /log ${Env:\windir}\logs\vcredist_x64.log"
            Name                              = "Microsoft Visual C++ 2010 x64 Redistributable Setup"
            ProductId                         = "1D8E6291-B0D5-35EC-8441-6616F567A0F7"
        }

        Script PerfCounters_Reset
        {
            DependsOn                         = @("[Package]VCRedistx86_Install", "[Package]VCRedistx64_Install")
            PsDscRunAsCredential              = $Node.WorkloadInstallerAccountCredential
            SetScript =
            {
                Write-Verbose "Resetting performance counters"
                $proc = Start-Process -FilePath "$($env:WINDIR)\system32\lodctr.exe" -ArgumentList "/R" -Wait -PassThru -Verbose
                Write-Verbose "Update performance counters returned: $($proc.ExitCode)"
                $proc = Start-Process -FilePath "$($env:WINDIR)\syswow64\lodctr.exe" -ArgumentList "/R" -Wait -PassThru -Verbose
                Write-Verbose "Update performance counters returned: $($proc.ExitCode)"
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                # Always reset performance counters
                return $false
            }
        }

        Package Biz_Install
        {
            PsDscRunAsCredential              = $Node.WorkloadInstallerAccountCredential
            DependsOn                         = "[Script]PerfCounters_Reset"
            Ensure                            = "Present"
            Path                              = "d:\BizTalk Server\Setup.exe"
            Arguments                         = "/CABPATH $($Node.ConfigurationDataPath)\BtsRedistW2K12EN64.cab /S $($Node.ConfigurationDataPath)\$($Node.InstallationFile) /L ${Env:\windir}\logs\BizInstall.log /norestart"
            Name                              = "Microsoft BizTalk Server 2013 R2"
            ProductId                         = "84E4A518-22DE-42F2-8F14-5457EB237C6E"
        }

        Package ASDK_Install
        {
            PsDscRunAsCredential              = $Node.WorkloadInstallerAccountCredential
            DependsOn                         = "[Package]Biz_Install"
            Ensure                            = "Present"
            Path                              = "d:\BizTalk Server\ASDK_x64\AdapterFramework64.msi"
            Arguments                         = "MUOPTIN=No /quiet /norestart"
            Name                              = "Windows Communication Foundation LOB Adapter SDK"
            ProductId                         = "1AD65E05-48F4-4AD4-9BAC-EBD3A3B33CCA"
        }

        Package AdapterPackX86_Install
        {
            PsDscRunAsCredential              = $Node.WorkloadInstallerAccountCredential
            DependsOn                         = "[Package]ASDK_Install"
            Ensure                            = "Present"
            Path                              = "d:\BizTalk Server\AdapterPack_x86\AdaptersSetup.msi"
            Arguments                         = "CEIP_OPTIN=false /qn ADDLOCAL=SqlFeature /norestart"
            Name                              = "Microsoft BizTalk Adapter Pack"
            ProductId                         = "C26D5F86-ADE0-4D2C-9255-F9BC29D5F78C"
        }

        Package AdapterPackX64_Install
        {
            PsDscRunAsCredential              = $Node.WorkloadInstallerAccountCredential
            DependsOn                         = "[Package]ASDK_Install"
            Ensure                            = "Present"
            Path                              = "d:\BizTalk Server\AdapterPack_x64\AdaptersSetup64.msi"
            Arguments                         = "CEIP_OPTIN=false /qn ADDLOCAL=SqlFeature /norestart"
            Name                              = "Microsoft BizTalk Adapter Pack(x64)"
            ProductId                         = "C9730C67-3498-4CC9-BB41-0A4B188D028D"
        }

        Script Biz_CUInstall
        {
            DependsOn                         = @("[Package]AdapterPackX86_Install", "[Package]AdapterPackX64_Install")
            SetScript =
            ({
                $arguments  = "/quiet /Log {0}\logs\BizCUInstall.log /norestart"
                $executable = "{1}\KB4038891\Setup.exe"
                Write-Verbose "Triggering Biz_CUInstall"
                $proc = Start-Process -FilePath $executable -ArgumentList $arguments -Wait -PassThru -Verbose

                if ($proc.ExitCode -eq 0)
                {{
                    Write-Verbose "Successfully installed Biz_CUInstall"
                }}
                elseif (($proc.ExitCode -eq 1641) -or ($proc.ExitCode -eq 3010))
                {{
                            Write-Verbose "Successfully installed Biz_CUInstall, but machine must be rebooted"
                }}
                else
                {{
                    $logOutput = ""
                    $logOutput = Get-Content -Path "{0}\logs\BizCUInstall.log" -ErrorAction SilentlyContinue
                    throw "Failed to install Biz_CUInstall with ExitCode: $($proc.ExitCode) and with LogOutput: $($logOutput)"
                }}
            } -f @($env:WINDIR, $Node.ConfigurationDataPath))
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                $cuNameTemplate = 'BizTalk Server 2013 R2 CU|KB4038891'
                $keyResults     = Get-ChildItem -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall" `
                                                -Recurse `
                                                -ErrorAction SilentlyContinue `
                                                | Where { $_.Name -match $cuNameTemplate }
                if ($keyResults.Count -gt 0)
                {
                    Write-Verbose "BizTalk CU installed"
                    return $true
                }

                Write-Verbose "BizTalk CU not installed"
                return $false
            }
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                           = $NodeName
            PSDscAllowPlainTextPassword        = $true
            PSDscAllowDomainUser               = $true

            ConfigurationDataPath              = $ConfigurationDataPath
            InstallationFile                   = $InstallationFile
            WorkloadInstallerAccountCredential = $WorkloadInstallerAccountCredential
        }
    )
}

Biz -ConfigurationData $ConfigurationData -OutputPath $OutputPath