<#
    .SYNOPSIS
        Configuration for Host Integration Server for BizTalk 2013 R2 VM's.
    .DESCRIPTION
        Configuration for Host Integration Server for BizTalk 2013 R2 VM's.
#>

param
(
    [Parameter(Mandatory=$true, Position = 0)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true, Position = 1)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true, Position = 2)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true, Position = 3)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory=$true, Position = 4)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $WorkloadInstallerAccountCredential,

    [Parameter(Mandatory=$false, Position = 5)]
    [ValidateNotNullOrEmpty()]
    [String] $ConfigurationDataPath = "${Env:SystemDrive}\Configurations\BizHIS"
)

Configuration BizHIS
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node $AllNodes.NodeName
    {
        Package HIS_Install
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
            Ensure               = "Present"
            Path                 = "d:\Setup.exe"
            Arguments            = "/S $($Node.ConfigurationDataPath)\HISInstall.xml /L ${Env:\windir}\logs\HISInstall.log /norestart"
            Name                 = "Microsoft Host Integration Server 2013"
            ProductId            = "DECD2591-F692-4682-B412-90BF58FE7787"
        }

        Script HIS_CUInstall
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
            DependsOn            = "[Package]HIS_Install"
            SetScript =
            ({
                $arguments  = "/quiet /Log {0}\logs\HISCUInstall.log /norestart"
                $executable = "{1}\HIS2013-RTM-KB3019572-amd64-ENU.exe"
                Write-Verbose "Triggering HIS_CUInstall"
                $proc = Start-Process -FilePath $executable -ArgumentList $arguments -Wait -PassThru -Verbose

                if ($proc.ExitCode -eq 0)
                {{
                    Write-Verbose "Successfully installed HIS_CUInstall"
                }}
                elseif (($proc.ExitCode -eq 1641) -or ($proc.ExitCode -eq 3010))
                {{
                    Write-Verbose "Successfully installed HIS_CUInstall, but machine must be rebooted"
                }}
                else
                {{
                    $logOutput = ""
                    $logOutput = Get-Content -Path "{0}\logs\HISCUInstall.log" -ErrorAction SilentlyContinue
                    throw "Failed to install HIS_CUInstall with ExitCode: $($proc.ExitCode) and with LogOutput: $($logOutput)"
                }}
            } -f @($env:WINDIR, $Node.ConfigurationDataPath))
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                $cuNameTemplate = 'CU3 Host Integration Server|KB3019572'
                $keyResults     = Get-ChildItem -Path HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\ `
                                                -Recurse `
                                                -ErrorAction SilentlyContinue `
                                                | Where { $_.Name -match $cuNameTemplate }
                if ($keyResults.Count -gt 0)
                {
                    Write-Verbose "Host Integration Server CU installed"
                    return $true
                }

                Write-Verbose "Host Integration Server CU not installed"
                return $false
            }
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                           = $NodeName
            PSDscAllowPlainTextPassword        = $true
            PSDscAllowDomainUser               = $true
            ConfigurationDataPath              = $ConfigurationDataPath
            WorkloadInstallerAccountCredential = $WorkloadInstallerAccountCredential
        }
    )
}

BizHIS -ConfigurationData $ConfigurationData -OutputPath $OutputPath