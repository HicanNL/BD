﻿param
(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    # SQL server admins group
    [Parameter(Mandatory = $true)]
    [String] $SqlAdminsGroup,

    # Service account under which the SQL Server wil run
    [Parameter(Mandatory = $true)]
    [PSCredential] $SqlServiceAccountCredential,

    # Installer account that invokes the setup
    [Parameter(Mandatory = $true)]
    [PSCredential] $WorkloadInstallerCredential,

    [Parameter(Mandatory = $true)]
    [String] $SubscriptionDomainFQDN,

    [Parameter(Mandatory = $true)]
    [String] $NetBiosDomainName,

    [Parameter(Mandatory = $true)]
    [PSCredential] $AdRunAsAccountCredential,

    #Instance name for SQL Server installation
    [Parameter(Mandatory = $false)]
    [String] $SqlInstanceName = "MSSQLSERVER",

    #Drive letter to use for the SQL data/log directories
    [Parameter(Mandatory = $false)]
    [String] $SqlDataDriveLetter = "S",

    # The SQL Collation
    [Parameter(Mandatory = $false)]
    [String] $SqlCollation = "SQL_Latin1_General_CP1_CI_AS"
)

Configuration SqlSa
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName NetworkingDsc
    Import-DscResource -ModuleName SqlServerDsc
    Import-DscResource -ModuleName xPSDesiredStateConfiguration
    Import-DscResource -ModuleName StorageDsc
    Import-DscResource -ModuleName xSmbShare
    Import-DscResource -ModuleName cInstallSqlServer
    Import-DscResource -ModuleName cMSDTC
    Import-DscResource -ModuleName xCredSSP
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node $AllNodes.NodeName
    {
        WindowsFeature SqlSa_RemoteADAdministrationPowerShellModule
        {
            Ensure = 'Present'
            Name   = 'RSAT-AD-PowerShell'
        }

        WindowsFeature SqlSa_DotNetFramework
        {
            Ensure = 'Present'
            Name   = 'NET-Framework-Core'
        }

        WindowsFeature SqlSa_DotNetFramework45
        {
            Ensure = 'Present'
            Name   = 'NET-Framework-45-Core'
        }

        WindowsFeature SqlSa_NetFramework
        {
            Ensure = 'Present'
            Name   = 'AS-NET-Framework'
        }

        UserRightsAssignment LogonAsAservice
        {
            Policy               = "log_on_as_a_service"
            Identity             = @(
                                       "$($Node.NetBIOSDomainName)\RESA-AD-LogOnAsAService",
                                       "NT SERVICE\ALL SERVICES",
                                       "$($Node.NetBIOSDomainName)\Workload-ServiceAccounts"
                                   )
            PsDscRunAsCredential = $Node.WorkloadInstallerCredential
        }

        UserRightsAssignment LogonAsABatchJob
        {
            Policy               = "log_on_as_a_batch_job"
            Identity             = @(
                                       "$($Node.NetBIOSDomainName)\RESA-AD-LogOnAsBatchJob",
                                       "NT SERVICE\ALL SERVICES",
                                       "$($Node.NetBIOSDomainName)\Workload-ServiceAccounts",
                                       "$($Node.NetBIOSDomainName)\Administrator"
                                   )
            PsDscRunAsCredential = $Node.WorkloadInstallerCredential
        }

        File SqlSa_SsisShareDirectory
        {
            Ensure          = 'Present'
            Type            = 'Directory'
            DestinationPath = 'C:\SSIS'
        }

        xSmbShare SqlSa_SsisShare
        {
            DependsOn  = '[File]SqlSa_SsisShareDirectory'
            Name       = 'SSIS'
            Path       = 'C:\SSIS'
            FullAccess = 'Everyone'
        }

        cMSDTC SqlSa_MsDtc
        {
            Ensure                            = 'Present'
            Name                              = 'Local'
            InboundTransactionsEnabled        = 1
            OutboundTransactionsEnabled       = 1
            RemoteClientAccessEnabled         = 1
            RemoteAdministrationAccessEnabled = 1
            AuthenticationLevel               = 'Mutual'
            LUTransactionsEnabled             = 1
            XATransactionsEnabled             = 0
        }

        Group AdminAccounts
        {
            GroupName        = "Administrators"
            MembersToInclude = @($Node.WorkloadInstallerUser)
            Ensure           = "Present"
        }

        WaitforDisk SqlSa_WaitforDataDisk
        {
            DiskId           = 1
            RetryIntervalSec = 2
            RetryCount       = 30
        }

        Disk SqlSa_DataDisk
        {
            DependsOn          = "[WaitforDisk]SqlSa_WaitforDataDisk"
            DiskId             = 1
            DriveLetter        = $Node.SqlDataDriveLetter
            FSLabel            = 'Data'
            AllocationUnitSize = 4096
        }

        WaitForVolume SqlSa_DataVolume
        {
            DependsOn          = "[Disk]SqlSa_DataDisk"
            DriveLetter        = $Node.SqlDataDriveLetter
            RetryIntervalSec   = 2
            RetryCount         = 30
        }

        Script Set_ManagedServiceAccount
        {
            PsDscRunAsCredential = $Node.AdRunAsAccountCredential
            DependsOn            = "[WaitForVolume]SqlSa_DataVolume"
            SetScript            =
            ({
                $ErrorActionPreference = "Stop"

                $isSuccessful = $false
                $maxRetries  = 10
                $retryCount  = 0
                do
                {{
                    try
                    {{
                        Write-Verbose "Constructing name for managed service account '{0}'"
                        $name = ("{0}" -replace '(.*\\)?(.*)','$2')

                        Write-Verbose "Getting managed service account '$name' from '{1}'"
                        $adServiceAccount = Get-ADServiceAccount -Identity $name -Server "{1}"

                        Write-Verbose "Installing managed service account '$($adServiceAccount.DistinguishedName)'"
                        Install-AdserviceAccount -Identity $adServiceAccount `
                                                 -Force `
                                                 -Verbose `
                                                 -ErrorAction SilentlyContinue

                        Write-Verbose "Testing managed service account '{0}'"
                        $isSuccessful = Test-ADServiceAccount -Identity $adServiceAccount.SamAccountName
                        Write-Verbose "Testing of managed service account returned '$isSuccessful'"

                        if (!$isSuccessful)
                        {{
                            throw "Could not install managed service account '{0}'"
                        }}
                    }}
                    catch
                    {{
                        $retryCount++
                        if ($retryCount -gt $maxRetries)
                        {{
                            Write-Verbose ($_.Exception | Format-List -Force | Out-String)
                            throw "Failed to install managed service account '{0}' after $maxRetries attempts: $($_.Exception.Message)"
                        }}

                        Start-Sleep -Seconds 3
                        Write-Verbose "Could not install managed service account '{0}', retrying [$retryCount/$maxRetries]..."
                    }}
                }} while (!$isSuccessful)
            } -f @($Node.SqlServiceAccountName, $Node.SubscriptionDomainFQDN))
            GetScript =
            ({
                $result = @()
                Write-Verbose "Getting managed service account '{0}'"
                $name = ("{0}" -replace '(.*\\)?(.*)','$2')
                $managedServiceAccountSamAccountName = (Get-ADServiceAccount -Identity $name -Server "{1}").SamAccountName

                Write-verbose "Returning result"
                $returnValue = New-Object HashTable
                $returnValue["Result"] = (Test-ADServiceAccount -Identity $managedServiceAccountSamAccountName)
                return $returnValue
            } -f @($Node.SqlServiceAccountName, $Node.SubscriptionDomainFQDN))
            TestScript =
            ({
                Write-Verbose "Testing managed service account '{0}'"
                $name = ("{0}" -replace '(.*\\)?(.*)','$2')
                $managedServiceAccountSamAccountName = (Get-ADServiceAccount -Identity $name -Server "{1}").SamAccountName
                return (Test-ADServiceAccount -Identity $managedServiceAccountSamAccountName)
            } -f @($Node.SqlServiceAccountName, $Node.SubscriptionDomainFQDN))
        }

        cInstallSqlSa SqlSa_InstallSQLServer
        {
            DependsOn            = "[Script]Set_ManagedServiceAccount"
            ProductKey           = $Node.Sql2012ProductKey
            Credential           = $Node.SqlServiceAccountCredential
            InstanceName         = $Node.SqlInstanceName
            DataDrive            = $Node.SqlDataDriveLetter + ":"
            Collation            = $Node.SqlCollation

            PsDscRunAsCredential = $Node.WorkloadInstallerCredential
        }

        Firewall SqlSa_SqlServerPortFirewallRule
        {
            DependsOn   = "[cInstallSqlSa]SqlSa_InstallSQLServer"
            Ensure      = "Present"
            Name        = "Microsoft Sql Server (port)"
            DisplayName = "Microsoft Sql Server (port)"
            Description = "An inbound rule to allow TCP traffic for SQL Server [TCP 1433]"
            Enabled     = "True"
            Protocol    = "TCP"
            LocalPort   = "1433"
        }

        Firewall SqlSa_SqlServerFirewallRule
        {
            DependsOn   = "[cInstallSqlSa]SqlSa_InstallSQLServer"
            Ensure      = "Present"
            Name        = "Microsoft Sql Server (application)"
            DisplayName = "Microsoft Sql Server (application)"
            Description = "An inbound rule to allow traffic for SQL Server [sqlservr.exe]"
            Enabled     = "True"
            Program     = "${Env:ProgramW6432}\Microsoft SQL Server\MSSQL11.$($Node.SqlInstanceName)\MSSQL\binn\sqlservr.exe"
        }

        Service SqlSa_AutostartSqlServerAgentService
        {
            DependsOn   = "[cInstallSqlSa]SqlSa_InstallSQLServer"
            Ensure      = "Present"
            Name        = "SQLSERVERAGENT"
            StartupType = "Automatic"
            State       = "Running"
        }

        Script SqlSa_AutostartServices
        {
            DependsOn   = "[cInstallSqlSa]SqlSa_InstallSQLServer"
            SetScript   =
            {
                $ErrorActionPreference = "Stop"

                Write-Verbose "Getting services that require change of startup type"
                $services = Get-Service | Where-Object {
                    ($_.Name -match "(SQLSERVERAGENT|MSSQLSERVER|MsDtsServer110)")
                }

                foreach ($service in $services)
                {
                    Write-Verbose "Configuring service '$($service.Name)'"
                    $service | Set-Service -StartupType Automatic
                    New-ItemProperty -Path "HKLM:\System\CurrentControlSet\Services\$($service.Name)" `
                                     -Name "DelayedAutostart" `
                                     -Value 1 `
                                     -PropertyType "DWORD" `
                                     -Force
                }
            }
            GetScript =
            {
                $result = @()

                Write-Verbose "Getting relevant services"
                $services = Get-Service | Where-Object {
                    ($_.Name -match "(SQLSERVERAGENT|MSSQLSERVER|MsDtsServer110)")
                }

                foreach ($service in $services)
                {
                    Write-Verbose "Retrieving service '$($service.Name)' information"
                    $delayedAutoStart = Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Services\$($service.Name)" `
                                                         -Name "DelayedAutoStart" `
                                                         -ErrorAction SilentlyContinue
                    $result += @{
                        "Name" = $service.Name
                        "StartMode" = $service.StartType.ToString()
                        "DelayedAutoStart" = $delayedAutoStart
                    }
                }

                return $result
            }
            TestScript =
            {
                Write-Verbose "Getting relevant services"
                $services = Get-Service | Where-Object {
                    ($_.Name -match "(SQLSERVERAGENT|MSSQLSERVER|MsDtsServer110)")
                }

                foreach ($service in $services)
                {
                    Write-Verbose "Checking service '$($service.Name)'"
                    $delayedAutoStart = Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Services\$($service.Name)" `
                                                         -Name "DelayedAutoStart" `
                                                         -ErrorAction SilentlyContinue
                    if (($service.StartType -ne [System.ServiceProcess.ServiceStartMode]::Automatic) -or ($delayedAutoStart -ne 1))
                    {
                        return $false
                    }
                }

                return $true
            }
        }

        SqlServerLogin SqlSa_CreateSQLLoginAdminsGroup
        {
            DependsOn        = "[cInstallSqlSa]SqlSa_InstallSQLServer"
            Ensure           = 'Present'
            Name             = $Node.SqlAdminsGroup
            ServerName       = "LocalHost"
            InstanceName     = $Node.SqlInstanceName
            LoginType        = 'WindowsGroup'
        }

        SqlServerRole SqlSa_AddAdminsToAdminRole
        {
            DependsOn        = "[cInstallSqlSa]SqlSa_InstallSQLServer", "[SqlServerLogin]SqlSa_CreateSQLLoginAdminsGroup"
            Ensure           = 'Present'
            MembersToInclude = @($Node.SqlAdminsGroup, "NT AUTHORITY\SYSTEM")
            ServerRoleName   = "sysadmin"
            ServerName       = "LocalHost"
            InstanceName     = $Node.SqlInstanceName
        }

        cConfigureAutogrow SqlSa_ConfigureAutogrowMaster
        {
            DependsOn        = "[cInstallSqlSa]SqlSa_InstallSQLServer"
            InstanceName     = $Node.SqlInstanceName
            DatabaseName     = 'Master'
            LogInitialSize   = 32768
            LogGrowthType    = 'KB'
            LogGrowth        = 32768
            DataInitialSize  = 65536
            DataGrowthType   = 'KB'
            DataGrowth       = 65536
        }

        cConfigureAutogrow SqlSa_ConfigureAutogrowModel
        {
            DependsOn        = "[cConfigureAutogrow]SqlSa_ConfigureAutogrowMaster"
            InstanceName     = $Node.SqlInstanceName
            DatabaseName     = 'Model'
            LogInitialSize   = 32768
            LogGrowthType    = 'KB'
            LogGrowth        = 32768
            DataInitialSize  = 65536
            DataGrowthType   = 'KB'
            DataGrowth       = 65536
        }

        cMaintenanceJobs SqlSa_MaintenanceJobs
        {
            DependsOn    = "[cConfigureAutogrow]SqlSa_ConfigureAutogrowModel", "[Service]SqlSa_AutostartSqlServerAgentService"
            InstanceName = $Node.SqlInstanceName
        }

        cTempDbFiles SqlSa_TempDbFiles
        {
            DependsOn    = "[cConfigureAutogrow]SqlSa_ConfigureAutogrowModel"
            InstanceName = $Node.SqlInstanceName
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                    = $NodeName
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser        = $true

            Sql2012ProductKey           = "FH666-Y346V-7XFQ3-V69JM-RHW28"
            SqlServiceAccountName       = $SqlServiceAccountCredential.UserName
            SqlServiceAccountCredential = New-Object PSCredential(($SqlServiceAccountCredential.UserName + "$"), $SqlServiceAccountCredential.GetNetworkCredential().SecurePassword)
            SqlInstanceName             = $SqlInstanceName
            SqlDataDriveLetter          = $SqlDataDriveLetter
            SqlAdminsGroup              = $SqlAdminsGroup
            SqlCollation                = $SqlCollation
            WorkloadInstallerCredential = $WorkloadInstallerCredential
            WorkloadInstallerUser       = $WorkloadInstallerCredential.UserName
            SubscriptionDomainFQDN      = $SubscriptionDomainFQDN
            NetBIOSDomainName           = $NetBiosDomainName
            AdRunAsAccountCredential    = $AdRunAsAccountCredential
        }
    )
}

SqlSA -ConfigurationData $ConfigurationData -Output $OutputPath
