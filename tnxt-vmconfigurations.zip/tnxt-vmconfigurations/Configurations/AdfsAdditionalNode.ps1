param
(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $DFSRoot,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $AdfsServiceAccountCredential,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [SecureString] $CertificatePassword,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $DSCRunAsAccountCredential,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $SQLServer,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $FederationServiceName
)

Configuration AdfsAdditionalNode
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node $AllNodes.NodeName
    {
        WindowsFeature ADFS_Federation
        {
            Ensure = 'Present'
            Name   = 'ADFS-Federation'
        }

        Script ADFS_AddFarmNode
        {
            PsDscRunAsCredential = $Node.DSCRunAsAccountCredential
            DependsOn            = "[WindowsFeature]ADFS_Federation"
            SetScript            =
            ({
                $ErrorActionPreference = "Stop"
                $cert = Get-ChildItem -Path "cert:\LocalMachine\My" | Where-Object {{ $_.Subject -match "{1}" }}
                $pass = ConvertTo-SecureString -String "{3}" -AsPlainText -Force

                if (!$cert)
                {{
                    try
                    {{
                        Write-Verbose "Importing certificate from '{5}\ADFS\{1}.pfx'"
                        $cert = Import-PfxCertificate -FilePath "{5}\ADFS\{1}.pfx" `
                                                      -CertStoreLocation "cert:\LocalMachine\My" `
                                                      -Password $pass
                    }}
                    catch
                    {{
                        throw "Failed to import certificate '{5}\ADFS\{1}.pfx': $($_.Exception.Message)"
                    }}
                }}

                Write-Verbose "Adding node '{0}' to the existing ADFS farm '{1}'"
                Add-AdfsFarmNode -CertificateThumbprint $cert.Thumbprint `
                                 -SQLConnectionString "Data Source={4};Integrated Security=True" `
                                 -GroupServiceAccountIdentifier "{2}" `
                                 | Out-Null

                Write-Verbose "Finished adding node '{0}' to the existing ADFS farm '{1}'"
            } -f @($env:COMPUTERNAME, $Node.FederationServiceName, $Node.AdfsServiceAccountCredential,
                   $Node.CertificatePassword, $Node.SQLServer, $Node.DFSRoot))
            GetScript            =
            {
                $ErrorActionPreference = "Stop"
                try
                {
                    return Get-AdfsProperties
                }
                catch
                {
                    return @{}
                }
            }
            TestScript           =
            {
                $ErrorActionPreference = "Stop"
                try
                {
                    $farm = Get-AdfsProperties
                    return $true
                }
                catch
                {
                    return $false
                }
            }
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                           = $NodeName
            PSDscAllowPlainTextPassword        = $true
            PSDscAllowDomainUser               = $true
            DFSRoot                            = $DFSRoot
            AdfsServiceAccountCredential       = $AdfsServiceAccountCredential
            CertificatePassword                = [System.Net.NetworkCredential]::New('', $CertificatePassword).Password
            DSCRunAsAccountCredential          = $DSCRunAsAccountCredential
            SQLServer                          = $SQLServer
            FederationServiceName              = $FederationServiceName
        }
    )
}

AdfsAdditionalNode -ConfigurationData $ConfigurationData -OutputPath $OutputPath