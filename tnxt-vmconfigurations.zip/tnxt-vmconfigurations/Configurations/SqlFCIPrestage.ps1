﻿param
(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    # Installer account that invokes the setup
    [Parameter(Mandatory = $true)]
    [PSCredential] $WorkloadInstallerCredential
)

Configuration SqlFCIPrestage
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node $AllNodes.NodeName
    {
        WindowsFeature Add_MultipathIO
        {
            Ensure    = 'Present'
            Name      = 'Multipath-IO'
        }

        WindowsFeature Add_FailoverClustering
        {
            Ensure    = 'Present'
            Name      = 'Failover-Clustering'
            DependsOn = '[WindowsFeature]Add_MultipathIO'
        }

        WindowsFeature Add_FailoverClusteringManagement
        {
            Ensure    = 'Present'
            Name      = 'RSAT-Clustering-Mgmt'
            DependsOn = '[WindowsFeature]Add_FailoverClustering'
        }

        WindowsFeature Add_ClusteringPowerShellFeature
        {
            Ensure    = 'Present'
            Name      = 'RSAT-Clustering-PowerShell'
            DependsOn = '[WindowsFeature]Add_FailoverClusteringManagement'
        }

        WindowsFeature Add_ClusteringCmdInterfaceFeature
        {
            Ensure    = 'Present'
            Name      = 'RSAT-Clustering-CmdInterface'
            DependsOn = '[WindowsFeature]Add_ClusteringPowerShellFeature'
        }

        WindowsFeature Add_ADPowerShell
        {
            Ensure    = 'Present'
            Name      = 'RSAT-AD-PowerShell'
            DependsOn = '[WindowsFeature]Add_ClusteringCmdInterfaceFeature'
        }

        Script MPClaim
        {
            DependsOn = '[WindowsFeature]Add_ADPowerShell'
            SetScript =
            {
                $disks      = @()
                $count      = 0
                $maxRetries = 5

                do
                {
                    $disks = Get-Disk | Where-Object { $_.Manufacturer -notlike "Msft*" -and $_.BusType -ne "ATA" } | Sort-Object -Property "Size"
                    Write-Verbose "Running MPClaim for storage deduplication"
                    $mpclaim = mpclaim -n -i -a
                    Start-Sleep -Seconds 5
                    Write-Verbose "Finished running MPClaim for storage deduplication"
                    Write-Verbose "Rescanning system disks"
                    $rescan  = Update-HostStorageCache
                    # Double check if the disks are properly present
                    $rescan  = "rescan" | diskpart
                    Write-Verbose "Finished rescanning system disks"
                    $count++
                    Write-Verbose "Retrying $count/$maxRetries"
                }
                while (($disks.Count -ne 4) -and ($count -ne $maxRetries))
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                # Do nothing
                return $false
            }
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                        = $NodeName
            NodeType                        = $NodeType
            PSDscAllowPlainTextPassword     = $true
            PSDscAllowDomainUser            = $true

            WorkloadInstallerCredential     = $WorkloadInstallerCredential
        }
    )
}

SqlFCIPrestage -ConfigurationData $ConfigurationData -Output $OutputPath