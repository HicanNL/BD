﻿param
(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    # Installer account that invokes the setup
    [Parameter(Mandatory = $true)]
    [PSCredential] $WorkloadInstallerCredential,

    # Subscription Installer account to configure AD permissions
    [Parameter(Mandatory = $true)]
    [PSCredential] $SubscriptionInstallerCredential,

    # Base / stripped name of the Cluster
    [Parameter(Mandatory = $true)]
    [String] $ClusterBase,

    # Name of the Cluster Group
    [Parameter(Mandatory = $true)]
    [String] $ClusterGroup,

    # Name of the SQL Cluster Group
    [Parameter(Mandatory = $true)]
    [String] $SQLClusterGroup,

    # IPAddress of the Cluster
    [Parameter(Mandatory = $true)]
    [String] $ClusterIPAddress,

    # IPAddress of the MSDTC Cluster Machine
    [Parameter(Mandatory = $true)]
    [String] $ClusterIPAddressDTC,

    # IP Subnet of the Cluster
    [Parameter(Mandatory = $true)]
    [String] $ClusterSubnet,

    # FileShare Witness resource for the Cluster Quorum
    [Parameter(Mandatory = $true)]
    [String] $FileShareWitnessResource,

    # FQDN of the Target (Cluster) Domain
    [Parameter(Mandatory = $true)]
    [String] $TargetDomainFQDN,

    # Workload Domain Controller
    [Parameter(Mandatory = $true)]
    [String] $WorkloadDomainController,

    # Target OU of the Cluster Computer Accounts
    [Parameter(Mandatory = $true)]
    [String] $ComputerOU,

    # Node type to determine if it is the First or Additional Server Node
    [Parameter(Mandatory = $true)]
    [String] $NodeType,

    # Comma separated list with drive letters for SAN disks (ordered by smallest size first)
    [Parameter(Mandatory = $true)]
    [String] $DriveLetters
)

Configuration SqlFCIPrimaryNodeConfig
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xFailOverCluster
    Import-DscResource -ModuleName cMSDTC
    Import-DscResource -ModuleName xActiveDirectory
    Import-DscResource -ModuleName StorageDsc
    Import-DscResource -ModuleName nHP3PARCLX

    Node $AllNodes.NodeName
    {
        Script RescanDisks
        {
            SetScript =
            {
                Write-Verbose "Rescanning system disks after mpclaim reboot"
                $rescan  = Update-HostStorageCache
                # Double check if the disks are properly present
                $rescan  = "rescan" | diskpart
                Write-Verbose "Finished rescanning system disks after mpclaim reboot"
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                # Do nothing
                return $false
            }
        }

        $diskNumber = 0
        $disks      = @()
        $diskInfo   = @()
        $retries    = 0
        $maxRetries = 30
        do
        {
            $retries++
            Start-Sleep -Seconds 5

            Write-Verbose "Retrieving disks [$retries/$maxRetries]"
            $disks = Get-Disk -ErrorAction SilentlyContinue `
                              | Where-Object { $_.Manufacturer -notlike "Msft*" -and $_.BusType -ne "ATA" } `
                              | Sort-Object -Property "Size"
        } while (!$disks -and ($retries -le $maxRetries))

        if ($disks)
        {
            foreach ($disk in $disks)
            {
                if ($diskNumber -lt $Node.DriveLetters.Count)
                {
                    $driveLetter = $Node.DriveLetters[$diskNumber]
                    $diskInfo += [PSCustomObject]@{
                        "DriveLetter" = $driveLetter
                        "Number"      = $disk.Number
                        "UniqueID"    = $disk.UniqueID
                        "Size"        = $disk.Size
                    }
                }
                $diskNumber++
            }
            $diskInfo | Export-Csv -Path $Node.DiskInfoFile
        }

        Script CheckSanDisks
        {
            DependsOn            = '[Script]RescanDisks'
            PsDscRunAsCredential = $Node.WorkloadInstallerCredential
            SetScript =
            ({
                $diskInfo = @()

                if (Test-Path "{1}")
                {{
                    Write-Verbose "Reading SAN disk info from '{1}'"
                    $diskInfo = Import-Csv -Path "{1}"
                }}

                if ($diskInfo.Count -lt {0})
                {{
                    throw "Could not locate enough SAN disks. Found $($diskInfo.Count) disk(s), required at least {0} disk(s)"
                }}
                Write-Verbose "Successfully retrieved SAN Disk Info"
            } -f @($Node.DriveLetters.Count, $Node.DiskInfoFile))
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                # Do nothing
                return $false
            }
        }

        xCluster CreateCluster
        {
            Name                          = $Node.ClusterName
            StaticIPAddress               = $Node.ClusterIPAddress
            DomainAdministratorCredential = $Node.WorkloadInstallerCredential
            DependsOn                     = '[Script]CheckSanDisks'
        }

        Script FSWQuorumFolder
        {
            PsDscRunAsCredential          = $Node.WorkloadInstallerCredential
            DependsOn                     = '[xCluster]CreateCluster'
            SetScript =
            ({
                Write-Verbose "Creating folder {0} in {1}"
                New-Item -Path "{1}\{0}" -Type Directory -Force
                Write-Verbose "Successfully created folder {0} in {1}"
            } -f @($Node.ClusterName, $Node.FileShareWitnessResource))
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            ({
                try
                {{
                    $folder = Get-Item -Path "{1}\{0}" -ErrorAction Stop
                    return $true
                }}
                catch
                {{
                    return $false
                }}
            } -f @($Node.ClusterName, $Node.FileShareWitnessResource))
        }

        Script FSWQuorumFolderSetPermission
        {
            PsDscRunAsCredential          = $Node.WorkloadInstallerCredential
            DependsOn                     = '[Script]FSWQuorumFolder'
            SetScript =
            ({
                $computer   = $false
                $count      = 0
                $maxRetries = 20
                do
                {{
                    Write-Verbose "Getting AD Computer: {0}"
                    try
                    {{
                        $computer = Get-ADComputer -Identity "{0}" `
                                                   -Server "{2}"
                    }}
                    catch
                    {{
                        $count++
                        Write-Verbose "Failed getting AD Computer. Error: $($_.Exception.Message): {0} - Retrying $count/$maxRetries"
                    }}
                    Start-Sleep -Seconds 5
                }}
                while (!($computer) -and ($count -ne $maxRetries))

                if ($computer)
                {{
                    Write-Verbose "Set permission on folder {0} in {1}"
                    $successful = $false
                    $count      = 0
                    $acl        = Get-Acl -Path "{1}\{0}"
                    $rights     = [System.Security.AccessControl.FileSystemRights]"FullControl"
                    $permission = "{2}\{0}$",$rights,"ContainerInherit,ObjectInherit","None","Allow"
                    $accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule $permission

                    do
                    {{
                        try
                        {{
                            $acl.AddAccessRule($accessRule)
                            $successful = $true
                        }}
                        catch
                        {{
                            $count++
                            Write-Verbose "Failed to set permissions. Error: $($_.Exception.Message): {0} - Retrying $count/$maxRetries"
                        }}
                        Start-Sleep -Seconds 5
                    }} while (!($successful) -and ($count -ne $maxRetries))

                    $acl | Set-Acl -Path "{1}\{0}"
                    Write-Verbose "Successfully set permission on folder {0} in {1}"
                }}
                else
                {{
                    throw "Failed to set permission on folder {0} in {1}"
                }}
            } -f @($Node.ClusterName, $Node.FileShareWitnessResource, $Node.TargetDomainFQDN, $Node.WorkloadInstallerCredential))
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            ({
                try
                {{
                    $acl = Get-Acl -Path "{1}\{0}" -ErrorAction Stop
                    if ($acl.Access.IdentityReference.Value -match "{0}")
                    {{
                        return $true
                    }}
                }}
                catch
                {{
                    return $false
                }}

                return $false
            } -f @($Node.ClusterName, $Node.FileShareWitnessResource))
        }

        xClusterQuorum ClusterQuorum
        {
            IsSingleInstance              = 'Yes'
            Type                          = 'NodeAndFileShareMajority'
            Resource                      = "$($Node.FileShareWitnessResource)\$($Node.ClusterName)"
            DependsOn                     = '[Script]FSWQuorumFolderSetPermission'
        }

        xADComputer CreateClusterComputerDTC
        {
            Ensure                        = 'Present'
            ComputerName                  = $Node.ClusterNameDTC
            DnsHostName                   = "$($Node.ClusterNameDTC).$($Node.TargetDomainFQDN)"
            Path                          = $Node.ComputerOU
            Description                   = "Failover cluster virtual network name account"
            Enabled                       = $true
            DomainController              = $Node.WorkloadDomainController
            DomainAdministratorCredential = $Node.WorkloadInstallerCredential
            DependsOn                     = '[xClusterQuorum]ClusterQuorum'
        }

        xADComputer CreateClusterComputerSQL
        {
            Ensure                        = 'Present'
            ComputerName                  = $Node.ClusterNameSQL
            DnsHostName                   = "$($Node.ClusterNameSQL).$($Node.TargetDomainFQDN)"
            Path                          = $Node.ComputerOU
            Description                   = "Failover cluster virtual network name account"
            Enabled                       = $true
            DomainController              = $Node.WorkloadDomainController
            DomainAdministratorCredential = $Node.WorkloadInstallerCredential
            DependsOn                     = '[xADComputer]CreateClusterComputerDTC'
        }

        Script SetClusterComputerPermission
        {
            PsDscRunAsCredential          = $Node.SubscriptionInstallerCredential
            DependsOn                     = '[xADComputer]CreateClusterComputerSQL'
            SetScript =
            ({
                $cluster    = ""
                $computerD  = ""
                $computerS  = ""
                $count      = 0
                $maxRetries = 40
                do
                {{
                    try
                    {{
                        Write-Verbose "Getting AD Computer: {0}"
                        $cluster = Get-ADComputer -Identity "{0}" `
                                                  -Server "{3}"

                        Write-Verbose "Getting AD Computer: {1}"
                        $computerD = Get-ADComputer -Identity "{1}" `
                                                    -Server "{3}"

                        Write-Verbose "Getting AD Computer: {2}"
                        $computerS = Get-ADComputer -Identity "{2}" `
                                                    -Server "{3}"
                    }}
                    catch
                    {{
                        $count++
                        Write-Verbose "Failed getting AD Computer. Error: $($_.Exception.Message): Retrying $count/$maxRetries"
                    }}
                    Start-Sleep -Seconds 5
                }}
                while ((!($cluster) -or !($computerD) -or!($computerS)) -and ($count -ne $maxRetries))

                $sid        = New-Object System.Security.Principal.SecurityIdentifier $cluster.SID
                $aclD       = Get-Acl -Path "AD:\$($computerD.DistinguishedName)"
                $aclS       = Get-Acl -Path "AD:\$($computerS.DistinguishedName)"
                $objectGuid = New-Object Guid "bf967a86-0de6-11d0-a285-00aa003049e2"
                $ace        = New-Object System.DirectoryServices.ActiveDirectoryAccessRule `
                                $sid,"GenericAll","Allow","All",$objectGuid
                $aclD.AddAccessRule($ace)
                $aclS.AddAccessRule($ace)

                Write-Verbose "Set permission on computer {1} for {0}"
                $set        = Set-Acl -Path "AD:\$($computerD.DistinguishedName)" -ACLObject $aclD
                Write-Verbose "Successfully set permission on computer {1} for {0}"

                Write-Verbose "Set permission on computer {2} for {0}"
                $set        = Set-Acl -Path "AD:\$($computerS.DistinguishedName)" -ACLObject $aclS
                Write-Verbose "Successfully set permission on computer {2} for {0}"
            } -f @($Node.ClusterName, $Node.ClusterNameDTC, $Node.ClusterNameSQL, $Node.TargetDomainFQDN))
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            ({
                try
                {{
                    $cluster    = ""
                    $computerD  = ""
                    $computerS  = ""
                    $count      = 0
                    $maxRetries = 40
                    do
                    {{
                        try
                        {{
                            Write-Verbose "Getting AD Computer: {1}"
                            $computerD = Get-ADComputer -Identity "{1}" `
                                                        -Server "{3}"

                            Write-Verbose "Getting AD Computer: {2}"
                            $computerS = Get-ADComputer -Identity "{2}" `
                                                        -Server "{3}"
                        }}
                        catch
                        {{
                            $count++
                            Write-Verbose "Failed getting AD Computer. Error: $($_.Exception.Message): Retrying $count/$maxRetries"
                        }}
                        Start-Sleep -Seconds 5
                    }}
                    while ((!($computerD) -or!($computerS)) -and ($count -ne $maxRetries))

                    $computerD  = Get-ADComputer -Identity "{1}"
                    $computerS  = Get-ADComputer -Identity "{2}"
                    $aclD       = Get-Acl -Path "AD:\$($computerD.DistinguishedName)" -ErrorAction Stop
                    $aclS       = Get-Acl -Path "AD:\$($computerS.DistinguishedName)" -ErrorAction Stop
                    if ($aclD.Access.IdentityReference.Value -match "{0}" -and `
                        $aclS.Access.IdentityReference.Value -match "{0}")
                    {{
                        return $true
                    }}
                }}
                catch
                {{
                    return $false
                }}

                return $false
            } -f @($Node.ClusterName, $Node.ClusterNameDTC, $Node.ClusterNameSQL, $Node.TargetDomainFQDN))
        }

        foreach ($disk in $diskInfo)
        {
            WaitForDisk $disk.Number
            {
                DiskId                    = $disk.UniqueID
                DiskIdType                = 'UniqueId'
                RetryIntervalSec          = 30
                RetryCount                = 6
                DependsOn                 = '[Script]SetClusterComputerPermission'
            }

            Script "$($disk.Number)_ClearReadOnlyFlag"
            {
                PsDscRunAsCredential      = $Node.WorkloadInstallerCredential
                DependsOn                 = "[WaitForDisk]$($disk.Number)"
                SetScript =
                ({
                    $ErrorActionPreference = "Stop"

                    Write-Verbose "Clearing Read-Only Flag on disk {0}"
                    try
                    {{
                        Set-Disk -IsReadOnly $false -Number {0} | Out-Null
                        Set-Disk -IsOffline $false -Number {0} | Out-Null
                        Set-Disk -IsReadOnly $false -Number {0} | Out-Null
                    }}
                    catch
                    {{
                        Write-Verbose "Failed to clear Read-Only Flag on disk {0}: $($_.Exception.Message)"
                    }}
                    Write-Verbose "Successfully cleared Read-Only Flag on disk {0}"
                } -f @($disk.Number))
                GetScript =
                {
                    # Do nothing
                }
                TestScript =
                ({
                    $ErrorActionPreference = "Stop"

                    try
                    {{
                        $flag = (Get-Disk -Number {0}).IsReadOnly

                        if (!$flag)
                        {{
                            return $true
                        }}
                    }}
                    catch
                    {{
                        return $false
                    }}

                    return $false
                } -f @($disk.Number))
            }

            Disk "$($disk.DriveLetter)Volume"
            {
                DiskId                    = $disk.UniqueID
                DiskIdType                = 'UniqueId'
                DriveLetter               = $disk.DriveLetter
                FSLabel                   = "Drive_$($disk.DriveLetter)"
                FSFormat                  = 'NTFS'
                DependsOn                 = "[Script]$($disk.Number)_ClearReadOnlyFlag"
            }

            xClusterDisk "$($disk.DriveLetter)Cluster"
            {
                Number                    = $disk.Number
                Ensure                    = 'Present'
                Label                     = "Drive_$($disk.DriveLetter)"
                DependsOn                 = "[Disk]$($disk.DriveLetter)Volume"
            }
        }

        Script SetClusterGroup
        {
            PsDscRunAsCredential          = $Node.WorkloadInstallerCredential
            DependsOn                     = '[Script]SetClusterComputerPermission'
            SetScript =
            ({
                $ErrorActionPreference = "Stop"

                $diskInfo = Import-Csv "C:\Temp\diskInfo.csv"
                $dtcDriveLetter = ($diskInfo | Sort-Object {{ [Int64]$_.Size }} | Select-Object -ExpandProperty "DriveLetter" -First 1)

                $clusterParameters1 = New-Object HashTable
                $clusterParameters1["Name"] = "{1}"
                $clusterParameters2 = New-Object HashTable
                $clusterParameters2["Address"] = "{2}"
                $clusterParameters2["SubnetMask"] = "{3}"
                $clusterParameters2["EnableDhcp"] = 0

                Write-Verbose "Creating Cluster Group: {0}"
                Add-ClusterGroup -Name "{0}" | Out-Null
                Stop-ClusterGroup -Name "{0}" | Out-Null

                Write-Verbose "Creating Cluster Group: {4}"
                Add-ClusterGroup -Name "{4}" | Out-Null
                Stop-ClusterGroup -Name "{4}" | Out-Null

                Write-Verbose "Moving Cluster Resource: '$dtcDriveLetter' to Cluster Group: {0}"
                Move-ClusterResource -Name "Drive_$dtcDriveLetter" -Group "{0}" | Out-Null

                Write-Verbose "Moving Cluster Resources to Cluster Group: '{4}'"
                foreach ($disk in ($diskInfo | Where-Object {{ $_.DriveLetter -ne $dtcDriveLetter }}))
                {{
                    Write-Verbose "Moving Cluster Resource: '$($disk.DriveLetter)' to Cluster Group: {4}"
                    Move-ClusterResource -Name "Drive_$($disk.DriveLetter)" -Group "{4}" | Out-Null
                }}

                Write-Verbose "Adding cluster resources, Name '{1}', IP Address '{2}', Dependency '{1}'"
                Add-ClusterResource -Name "{1}" -Group "{0}" -ResourceType "Network Name" | Out-Null
                Get-ClusterResource "{1}" | Set-ClusterParameter –Multiple $clusterParameters1 | Out-Null
                Add-ClusterResource -Name "IP Address {2}" -ResourceType "IP Address" -Group "{0}" | Out-Null
                Get-ClusterResource "IP Address {2}" | Set-ClusterParameter –Multiple $clusterParameters2 | Out-Null
                Add-ClusterResourceDependency -Resource "{1}" -Provider "IP Address {2}"

                Write-Verbose "Adding cluster resource '{5}' to cluster group '{0}'"
                Get-ClusterGroup -Name "{0}" | Add-ClusterResource -Name "{5}" -ResourceType "Distributed Transaction Coordinator" | Out-Null

                Write-Verbose "Create dependency between '{5}' and Cluster Name '{1}'"
                Add-ClusterResourceDependency -Resource "{5}" -Provider "{1}" | Out-Null

                Write-Verbose "Create dependency between '{5}' and disk volume 'Drive_$dtcDriveLetter'"
                Stop-ClusterResource -Name "Drive_$dtcDriveLetter" -IgnoreLocked | Out-Null
                Add-ClusterResourceDependency -Resource "{5}" -Provider "Drive_$dtcDriveLetter" | Out-Null
                Start-ClusterResource -Name "Drive_$dtcDriveLetter" | Out-Null

                $clusterGroup = Start-ClusterGroup -Name "{0}"
                if ($clusterGroup.State -ne [Microsoft.FailoverClusters.PowerShell.ClusterGroupState]::Online)
                {{
                    throw "Failed to bring cluster group {1} online"
                }}

                Write-Verbose "Successfully created Cluster Group: '{0}'"
            } -f @($Node.ClusterGroup, $Node.ClusterNameDTC, $Node.ClusterIPAddressDTC, $Node.ClusterSubnet, $Node.SQLClusterGroup, $Node.ClusterResourceNameDTC))
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            ({
                $primaryGroup = Get-ClusterGroup | Where {{ $_.Name -eq "{0}" }}
                $sqlGroup = Get-ClusterGroup | Where {{ $_.Name -eq "{1}" }}
                return ($primaryGroup -and $sqlGroup)
            } -f @($Node.ClusterGroup, $Node.SQLClusterGroup))
        }

        Registry ClusterDelayedAutostart
        {
            Ensure                            = "Present"
            Key                               = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\ClusSvc"
            ValueName                         = "DelayedAutostart"
            ValueType                         = "DWORD"
            ValueData                         = 1
            DependsOn                         = '[Script]SetClusterGroup'
        }

        cMSDTC ConfigureMsDtcLocal
        {
            Ensure                            = 'Present'
            Name                              = 'Local'
            InboundTransactionsEnabled        = 1
            OutboundTransactionsEnabled       = 1
            RemoteClientAccessEnabled         = 1
            RemoteAdministrationAccessEnabled = 1
            AuthenticationLevel               = 'Mutual'
            LUTransactionsEnabled             = 1
            XATransactionsEnabled             = 0
        }

        cMSDTC ConfigureMsDtcCluster
        {
            Ensure                            = 'Present'
            PsDscRunAsCredential              = $Node.WorkloadInstallerCredential
            Name                              = $Node.ClusterResourceNameDTC
            InboundTransactionsEnabled        = 1
            OutboundTransactionsEnabled       = 1
            RemoteClientAccessEnabled         = 1
            RemoteAdministrationAccessEnabled = 1
            AuthenticationLevel               = 'Mutual'
            LUTransactionsEnabled             = 1
            XATransactionsEnabled             = 0
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                        = $NodeName
            NodeType                        = $NodeType
            PSDscAllowPlainTextPassword     = $true
            PSDscAllowDomainUser            = $true

            WorkloadInstallerCredential     = $WorkloadInstallerCredential
            SubscriptionInstallerCredential = $SubscriptionInstallerCredential
            WorkloadDomainController        = $WorkloadDomainController
            ComputerOU                      = $ComputerOU
            ClusterGroup                    = $ClusterGroup
            SQLClusterGroup                 = $SQLClusterGroup
            ClusterName                     = "$($ClusterBase)C"
            ClusterNameDTC                  = "$($ClusterBase)D"
            ClusterNameSQL                  = "$($ClusterBase)S"
            ClusterIPAddress                = $ClusterIPAddress
            ClusterIPAddressDTC             = $ClusterIPAddressDTC
            ClusterSubnet                   = $ClusterSubnet
            ClusterResourceNameDTC          = "MSDTC-Cluster"
            FileShareWitnessResource        = $FileShareWitnessResource
            TargetDomainFQDN                = $TargetDomainFQDN
            DriveLetters                    = $DriveLetters -split ","
            DiskInfoFile                    = "C:\Temp\diskInfo.csv"
        }
    )
}

SqlFCIPrimaryNodeConfig -ConfigurationData $ConfigurationData -Output $OutputPath