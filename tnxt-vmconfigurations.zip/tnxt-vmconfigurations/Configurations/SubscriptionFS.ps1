param
(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory = $true, Position = 1)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory = $true, Position = 2)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory = $true, Position = 3)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory = $false, Position = 4)]
    [String] $FSBackendDataDriveLetter = "S"
)

Configuration SubscriptionFS
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName StorageDsc
    Import-DscResource -ModuleName cNtfsAccessControl
    Import-DscResource -ModuleName xSmbShare

    Node $AllNodes.NodeName
    {
        WindowsFeature FileAndiSCSIServices
        {
            Ensure = 'Present'
            Name   = 'File-Services'
        }

        WindowsFeature FileServer
        {
            Ensure = 'Present'
            Name   = 'FS-FileServer'
        }

        WindowsFeature DFSNamespaces
        {
            Ensure = 'Present'
            Name   = 'FS-DFS-Namespace'
        }

        WindowsFeature DFSReplication
        {
            Ensure = 'Present'
            Name   = 'FS-DFS-Replication'
        }

        WindowsFeature DFSManagementTools
        {
            Ensure = 'Present'
            Name   = 'RSAT-DFS-Mgmt-Con'
        }

        WindowsFeature NFSAdmin
        {
            Ensure = 'Present'
            Name   = 'RSAT-NFS-Admin'
        }

        WindowsFeature FileServicesTools
        {
            Ensure = 'Present'
            Name   = 'RSAT-File-Services'
        }

        WindowsFeature DotNetFramework45
        {
            Ensure = 'Present'
            Name   = 'NET-Framework-45-Core'
        }

        WindowsFeature WCFServices
        {
            Ensure = 'Present'
            Name   = 'NET-WCF-Services45'
        }

        WindowsFeature NETWCFTCPPortSharing45
        {
            Ensure = 'Present'
            Name   = 'NET-WCF-TCP-PortSharing45'
        }

        File DFSRootsAndFileShare
        {
            Ensure          = 'Present'
            Type            = 'Directory'
            DestinationPath = 'C:\DFSRoots\FileShare'
        }

        xSmbShare FileShare
        {
            Ensure     = 'Present'
            Name       = 'FileShare'
            Path       = 'C:\DFSRoots\FileShare'
            ReadAccess = 'Everyone'
            DependsOn  = '[File]DFSRootsAndFileShare'
        }

        WaitforDisk FSBackend_WaitforDataDisk
        {
            DiskId           = 1
            RetryIntervalSec = 2
            RetryCount       = 30
        }

        Disk FSBackend_DataDisk
        {
            DiskId             = 1
            DriveLetter        = $Node.FSBackendDataDriveLetter
            FSLabel            = 'Data'
            AllocationUnitSize = 4096
            DependsOn          = "[WaitforDisk]FSBackend_WaitforDataDisk"
        }

        WaitForVolume FSBackend_DataVolume
        {
            DriveLetter        = $Node.FSBackendDataDriveLetter
            RetryIntervalSec   = 2
            RetryCount         = 30
            DependsOn          = "[Disk]FSBackend_DataDisk"
        }

        File DataFolder
        {
            Ensure          = 'Present'
            Type            = 'Directory'
            DestinationPath = 'S:\Data'
            DependsOn       = '[WaitForVolume]FSBackend_DataVolume'
        }

        cNtfsPermissionsInheritance DisableInheritanceDataFolder
        {
            Path              = 'S:\Data'
            Enabled           = $false
            PreserveInherited = $true
            DependsOn         = '[File]DataFolder'
        }

        cNtfsPermissionEntry DataFolderpermissionsSet1
        {
            Ensure                   = 'Present'
            Path                     = 'S:\Data'
            Principal                = 'BUILTIN\Users'
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType  = 'Allow'
                    FileSystemRights   = 'Read'
                    Inheritance        = 'ThisFolderOnly'
                    NoPropagateInherit = $false
                }
            )
            DependsOn                  = '[cNtfsPermissionsInheritance]DisableInheritanceDataFolder'
        }

        xSmbShare DataFolder
        {
            Ensure     = 'Present'
            Name       = 'Data$'
            Path       = 'S:\Data'
            FullAccess = 'Authenticated Users'
            DependsOn  = '[File]DataFolder'
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                               = $NodeName
            PSDscAllowPlainTextPassword            = $true
            PSDscAllowDomainUser                   = $true

            FSBackendDataDriveLetter               = $FSBackendDataDriveLetter
        }
    )
}

SubscriptionFS -ConfigurationData $ConfigurationData -OutputPath $OutputPath
