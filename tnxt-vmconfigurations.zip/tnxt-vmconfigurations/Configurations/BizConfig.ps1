param
(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NetbiosDomainName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $SSOServiceAccountCredentials,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $WorkloadInstallerAccountCredential,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $Name,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $WorkloadCode,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $SQLServer,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $HostInstanceCredential,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $IsolatedHostInstanceCredential,

    # Node type to determine if it is the First or Additional Server Node
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeType,

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [String] $ConfigurationDataPath = "${Env:SystemDrive}\Configurations\Biz",

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [String] $ConfigurationFile = "BTSConfig.xml",

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [String] $SSOAffiliateAdministratorsGroup = "RESA-$WorkloadCode-$Name-SSOAffiliateAdministrators",

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [String] $SSOAdministratorsGroup = "RESA-$WorkloadCode-$Name-SSOAdministrators",

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [String] $IsolatedHostUsersGroup = "RESA-$WorkloadCode-$Name-BizTalkIsolatedHostUsers",

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [String] $AdministratorsGroup = "RESA-$WorkloadCode-$Name-BizTalkAdministrators",

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [String] $OperatorsGroup = "RESA-$WorkloadCode-$Name-BizTalkOperators",

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [String] $HostUsersGroup = "RESA-$WorkloadCode-$Name-BizTalkHostUsers"
)

Configuration BizConfig
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DSCResource -ModuleName cBTSConfigXML

    Node $AllNodes.NodeName
    {
        cBTSConfigXML Biz_ConfigXML
        {
            Ensure                            = 'Present'
            Path                              = "$($Node.ConfigurationDataPath)\$($Node.ConfigurationFile)"
            SSOServiceAccount                 = $Node.SSOServiceAccount
            SSOAdministratorsGroup            = $Node.SSOAdministratorsGroup
            SSOAffiliateAdministratorsGroup   = $Node.SSOAffiliateAdministratorsGroup
            NetbiosDomainName                 = $Node.NetbiosDomainName
            SSOPassword                       = $Node.SSOPassword
            SQLServer                         = $Node.SQLServer
            SSODB                             = 'SSODB'
            ManagementDB                      = 'BizTalkMgmtDb'
            MessageBoxDB                      = 'BizTalkMsgBoxDb'
            TrackingDB                        = 'BizTalkDTADb'
            AdministratorsGroup               = $Node.AdministratorsGroup
            OperatorsGroup                    = $Node.OperatorsGroup
            HostUsersGroup                    = $Node.HostUsersGroup
            HostInstanceAccount               = $Node.HostInstanceAccount
            HostInstancePassword              = $Node.HostInstancePassword
            IsolatedHostInstanceAccount       = $Node.IsolatedHostInstanceAccount
            IsolatedHostInstancePassword      = $Node.IsolatedHostInstancePassword
            IsolatedHostUsersGroup            = $Node.IsolatedHostUsersGroup
            InitialConfig                     = $Node.NodeType
        }

        Script Biz_Config
        {
            PsDscRunAsCredential              = $Node.WorkloadInstallerAccountCredential
            DependsOn                         = "[cBTSConfigXML]Biz_ConfigXML"
            SetScript =
            ({
                $executable      = "{3}\Microsoft BizTalk Server 2013 R2\Configuration.exe"
                $logFile         = "{0}\logs\BizConfig_$(Get-Date -Format 'hhmmss').log"
                $unconfigureArgs = "/u /noprogressbar"
                $configureArgs   = "/s {1}\{2} /l $logFile /noprogressbar"

                # always run unconfigure first (ignoring the result)
                Write-Verbose "Unconfiguring Biztalk"
                $proc = Start-Process -FilePath $executable -ArgumentList $unconfigureArgs -Wait -PassThru -Verbose
                Write-Verbose "Unconfiguring Biztalk finished with exit code: $($proc.ExitCode)"

                # run configure
                Write-Verbose "Configuring Biztalk"
                $proc = Start-Process -FilePath $executable -ArgumentList $configureArgs -Wait -PassThru -Verbose
                if ($proc.ExitCode -eq 0)
                {{
                    Write-Verbose "Successfully configured Biztalk"
                }}
                elseif (($proc.ExitCode -eq 1641) -or ($proc.ExitCode -eq 3010))
                {{
                    Write-Verbose "Successfully configured Biztalk, but machine must be rebooted"
                    $global:DSCMachineStatus = 1
                }}
                else
                {{
                    $logOutput = Get-Content -Path $logFile -ErrorAction SilentlyContinue
                    throw "Failed to configure Biztalk with ExitCode: $($proc.ExitCode) and LogOutput: $($logOutput)"
                }}
            } -f @($env:WINDIR, $Node.ConfigurationDataPath, $Node.ConfigurationFile, ${env:ProgramFiles(x86)}))
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                # Temporary default return false till there is a good check on the configure available
                return $false
            }
        }

        Script Set_MessagingMaxReceiveInterval
        {
            PsDscRunAsCredential = $Node.SSOServiceAccountCredential
            DependsOn            = "[Script]Biz_Config"
            SetScript =
            {
                $btsHosts = Get-WmiObject -Class "MSBTS_HostSetting" -Namespace "root\MicrosoftBizTalkServer"
                foreach ($btsHost in $btsHosts)
                {
                    Write-Verbose "Checking MessagingMaxReceiveInterval on host $($btsHost.Name)"
                    $oldInterval = $btsHost.MessagingMaxReceiveInterval
                    if ($oldInterval -ne 100)
                    {
                        $btsHost.MessagingMaxReceiveInterval = 100
                        $btsHost.Put() | Out-Null
                        Write-Verbose "Changed MessagingMaxReceiveInterval from $($oldInterval) to $($btsHost.MessagingMaxReceiveInterval) for host $($btsHost.Name)"
                    }
                }
            }
            GetScript =
            {
                $result = @()
                $btsHosts = Get-WmiObject -Class "MSBTS_HostSetting" -Namespace "root\MicrosoftBizTalkServer"
                foreach ($btsHost in $btsHosts)
                {
                    Write-Verbose "Retrieving MessagingMaxReceiveInterval for host $($btsHost.Name)"
                    $result += "$($btsHost.Name) = $($btsHost.MessagingMaxReceiveInterval)"
                }

                return @{ "Result" = ($result -join ", ") }
            }
            TestScript =
            {
                $btsHosts = Get-WmiObject -Class "MSBTS_HostSetting" -Namespace "root\MicrosoftBizTalkServer"
                foreach ($btsHost in $btsHosts)
                {
                    Write-Verbose "Checking MessagingMaxReceiveInterval on host $($btsHost.Name)"
                    if ($btsHost.MessagingMaxReceiveInterval -ne 100)
                    {
                        return $false
                    }
                }

                return $true
            }
        }

        Script WCFAdapter_Install
        {
            PsDscRunAsCredential = $Node.SSOServiceAccountCredential
            DependsOn            = "[Script]Set_MessagingMaxReceiveInterval"
            SetScript            =
            {
                Write-Verbose "Install the WCF SQL Adapter"
                $adapterClass = [WMIClass]"root\MicrosoftBizTalkServer:MSBTS_AdapterSetting"
                $adapter = $adapterClass.CreateInstance()
                $adapter.Name = "WCF-SQL"
                $adapter.Comment = "WCF SQL adapter"
                $adapter.Constraints = 779
                $adapter.MgmtCLSID = "{59B35D03-6A06-4734-A249-EF561254ECF7}"
                $adapter.Put() | Out-Null
                Write-Verbose "Finished installing the WCF SQL Adapter"
            }
            GetScript            =
            {
                # Do nothing
            }
            TestScript           =
            {
                # This config can always run without problems
                return $false
            }
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                           = $NodeName
            NodeType                           = $NodeType
            PSDscAllowPlainTextPassword        = $true
            PSDscAllowDomainUser               = $true

            SQLServer                          = $SQLServer
            NetbiosDomainName                  = $NetbiosDomainName
            SSOServiceAccountCredential        = $SSOServiceAccountCredentials
            SSOServiceAccount                  = $SSOServiceAccountCredentials.UserName.Split("\")[1]
            SSOPassword                        = $SSOServiceAccountCredentials.GetNetworkCredential().password
            ConfigurationDataPath              = $ConfigurationDataPath
            SSOAdministratorsGroup             = "$NetbiosDomainName\$SSOAdministratorsGroup"
            SSOAffiliateAdministratorsGroup    = "$NetbiosDomainName\$SSOAffiliateAdministratorsGroup"
            WorkloadInstallerAccountCredential = $WorkloadInstallerAccountCredential
            AdministratorsGroup                = "$NetbiosDomainName\$AdministratorsGroup"
            OperatorsGroup                     = "$NetbiosDomainName\$OperatorsGroup"
            HostUsersGroup                     = "$NetbiosDomainName\$HostUsersGroup"
            HostInstanceCredential             = $HostInstanceCredential
            HostInstanceAccount                = $HostInstanceCredential.UserName.Split("\")[1]
            HostInstancePassword               = $HostInstanceCredential.GetNetworkCredential().password
            IsolatedHostInstanceCredential     = $IsolatedHostInstanceCredential
            IsolatedHostInstanceAccount        = $IsolatedHostInstanceCredential.UserName.Split("\")[1]
            IsolatedHostInstancePassword       = $IsolatedHostInstanceCredential.GetNetworkCredential().password
            IsolatedHostUsersGroup             = "$NetbiosDomainName\$IsolatedHostUsersGroup"
            ConfigurationFile                  = $ConfigurationFile
        }
    )
}

BizConfig -ConfigurationData $ConfigurationData -OutputPath $OutputPath