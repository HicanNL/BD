param
(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $DFSRoot,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $AdfsServiceAccountCredential,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [SecureString] $CertificatePassword,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $DSCRunAsAccountCredential,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $SQLServer,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $FederationServiceName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $FederationServiceDisplayName
)

Configuration AdfsPrimaryNode
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName cSelfSignedCert

    Node $AllNodes.NodeName
    {
        WindowsFeature ADFS_Federation
        {
            Ensure = 'Present'
            Name   = 'ADFS-Federation'
        }

        cSelfSignedCert CreateCert
        {
            Subject       = "CN=$($Node.FederationServiceName)"
            StoreLocation = 'LocalMachine'
            StoreName     = 'My'
            Ensure        = 'Present'
        }

        Script ADFS_ConfigureFarm
        {
            PsDscRunAsCredential = $Node.DSCRunAsAccountCredential
            DependsOn            = "[cSelfSignedCert]CreateCert"
            SetScript            =
            ({
                $ErrorActionPreference = "Stop"
                $cert = Get-ChildItem -Path "cert:\LocalMachine\My" | Where {{ $_.Subject -match "{0}" }}
                $pass = ConvertTo-SecureString -String "{3}" -AsPlainText -Force

                Write-Verbose "Configuring ADFS farm '{0}' - '{1}'"
                Install-AdfsFarm -CertificateThumbprint $cert.Thumbprint `
                                 -FederationServiceName "{0}" `
                                 -FederationServiceDisplayName "{1}" `
                                 -SQLConnectionString "Data Source={4};Integrated Security=True" `
                                 -GroupServiceAccountIdentifier "{2}" `
                                 -Confirm:$false `
                                 -OverwriteConfiguration:$true

                if (!(Test-Path "{5}\ADFS"))
                {{
                    Write-Verbose "Creating folder '{5}\ADFS'"
                    New-Item "{5}\ADFS" -ItemType Directory -Force | Out-Null
                }}

                try
                {{
                    Write-Verbose "Exporting certificate '$($cert.Thumbprint)' to '{5}\ADFS\{0}.pfx'"
                    Export-PfxCertificate -Cert $cert `
                                          -FilePath "{5}\ADFS\{0}.pfx" `
                                          -Password $pass `
                                          | Out-Null
                }}
                catch
                {{
                    throw "Failed to export certificate '{5}\ADFS\{0}'.pfx, error: $($_.Exception.Message)"
                }}

                Write-Verbose "Finished configuring ADFS farm '{0}' - '{1}'"
            } -f @($Node.FederationServiceName, $Node.FederationServiceDisplayName, $Node.AdfsServiceAccountCredential,
                   $Node.CertificatePassword, $Node.SQLServer, $Node.DFSRoot))
            GetScript            =
            {
                $ErrorActionPreference = "Stop"
                try
                {
                    return Get-AdfsProperties
                }
                catch
                {
                    return @{}
                }
            }
            TestScript           =
            {
                $ErrorActionPreference = "Stop"
                try
                {
                    $farm = Get-AdfsProperties
                    return $true
                }
                catch
                {
                    return $false
                }
            }
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                        = $NodeName
            PSDscAllowPlainTextPassword     = $true
            PSDscAllowDomainUser            = $true
            DFSRoot                         = $DFSRoot
            AdfsServiceAccountCredential    = $AdfsServiceAccountCredential
            CertificatePassword             = [System.Net.NetworkCredential]::New('', $CertificatePassword).Password
            DSCRunAsAccountCredential       = $DSCRunAsAccountCredential
            SQLServer                       = $SQLServer
            FederationServiceName           = $FederationServiceName
            FederationServiceDisplayName    = $FederationServiceDisplayName
        }
    )
}

AdfsPrimaryNode -ConfigurationData $ConfigurationData -OutputPath $OutputPath