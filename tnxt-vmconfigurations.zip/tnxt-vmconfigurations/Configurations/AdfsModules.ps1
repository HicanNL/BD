param
(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles
)

Configuration AdfsModules
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName cChoco

    Node $AllNodes.NodeName
    {
        # Ensures chocolatey is installed
        cChocoInstaller Default_InstallChocolatey
        {
            ChocoInstallScriptUrl = $Node.ChocoFiles
            InstallDir            = "c:\Choco"
        }

        # useFipsCompliantChecksums
        Script ChocoEnableFipsCompliantChecksums
        {
            GetScript = {
                $chocoPath = "C:\Choco\Choco.exe"
                Start-Process -FilePath $chocoPath -ArgumentList "list -lo" -NoNewWindow -Wait
            }
            TestScript = {
                $chocoExists = Test-Path "C:\Choco\Choco.exe"
                return (-not ($chocoExists))
            }
            SetScript = {
                $chocoPath = "C:\Choco\Choco.exe"
                $proc = Start-Process -FilePath $chocoPath -ArgumentList "feature enable -n useFipsCompliantChecksums" -PassThru -NoNewWindow -Wait

                if ($proc.ExitCode -eq 0)
                {
                    Write-Verbose "Successfully installed ChocoEnableFipsCompliantChecksums"
                }
                elseif (($proc.ExitCode -eq 1641) -or ($proc.ExitCode -eq 3010))
                {
                    Write-Verbose "Successfully installed ChocoEnableFipsCompliantChecksums, but machine must be rebooted"
                }
                else
                {
                    throw "Failed to install ChocoEnableFipsCompliantChecksums with ExitCode: $($proc.ExitCode)"
                }
            }
        }

        Script ChocoRemoveDefaultSource
        {
            GetScript = {
                #nothing to do
            }
            TestScript = {
                return $false
            }
            SetScript = {
                $chocoPath = "C:\Choco\Choco.exe"
                $proc = Start-Process -FilePath $chocoPath -ArgumentList "source remove -n=chocolatey -f -y" -PassThru -NoNewWindow -Wait

                if ($proc.ExitCode -eq 0)
                {
                    Write-Verbose "Successfully installed ChocoRemoveDefaultSource"
                }
                elseif (($proc.ExitCode -eq 1641) -or ($proc.ExitCode -eq 3010))
                {
                    Write-Verbose "Successfully installed ChocoRemoveDefaultSource, but machine must be rebooted"
                }
                else
                {
                    throw "Failed to install ChocoRemoveDefaultSource with ExitCode: $($proc.ExitCode)"
                }
            }
        }

        cChocoPackageInstaller Install_cSelfSignedCert
        {
            DependsOn = "[cChocoInstaller]Default_InstallChocolatey"
            Ensure    = "Present"
            Name      = "cSelfSignedCert"
            Source    = $Node.ChocoSource
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName    = $NodeName
            ChocoSource = "$ChocoSource/nuget"
            ChocoFiles  = $ChocoFiles
        }
    )
}

AdfsModules -ConfigurationData $ConfigurationData -OutputPath $OutputPath
