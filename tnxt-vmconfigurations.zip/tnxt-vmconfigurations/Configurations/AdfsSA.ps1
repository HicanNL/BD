param
(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $DSCRunAsAccountCredential,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $FederationServiceName,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $AdfsServiceAccountCredential
)

Configuration AdfsSA
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName cSelfSignedCert

    Node $AllNodes.NodeName
    {
        WindowsFeature ADFS_Federation
        {
            Ensure = 'Present'
            Name   = 'ADFS-Federation'
        }

        cSelfSignedCert CreateCert
        {
            Subject       = "CN=$($Node.FederationServiceName)"
            StoreLocation = 'LocalMachine'
            StoreName     = 'My'
            Ensure        = 'Present'
        }

        Script ADFS_ConfigureStandalone
        {
            PsDscRunAsCredential = $Node.DSCRunAsAccountCredential
            DependsOn            = "[cSelfSignedCert]CreateCert"
            SetScript            =
            ({
                 $ErrorActionPreference = "Stop"
                 $cert = Get-ChildItem -Path "cert:\LocalMachine\My" | Where-Object {{ $_.Subject -match "{0}" }}

                 Write-Verbose "Configuring ADFS standalone '{0}'"
                 Install-AdfsFarm -CertificateThumbprint $cert.Thumbprint `
                                  -FederationServiceName "{0}" `
                                  -GroupServiceAccountIdentifier "{1}" `
                                  -Confirm:$false `
                                  -OverwriteConfiguration:$true

                 Write-Verbose "Finished configuring ADFS standalone '{0}'"
            } -f @($Node.FederationServiceName, $Node.AdfsServiceAccountCredential))
            GetScript            =
            {
                $ErrorActionPreference = "Stop"
                try
                {
                    return Get-AdfsProperties
                }
                catch
                {
                    return @{}
                }
            }
            TestScript           =
            {
                $ErrorActionPreference = "Stop"
                try
                {
                    $standalone = Get-AdfsProperties
                    return $true
                }
                catch
                {
                    return $false
                }
            }
        }

    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                        = $NodeName
            PSDscAllowPlainTextPassword     = $true
            PSDscAllowDomainUser            = $true
            DSCRunAsAccountCredential       = $DSCRunAsAccountCredential
            FederationServiceName           = $FederationServiceName
            AdfsServiceAccountCredential    = $AdfsServiceAccountCredential
        }
    )
}

AdfsSA -ConfigurationData $ConfigurationData -OutputPath $OutputPath
