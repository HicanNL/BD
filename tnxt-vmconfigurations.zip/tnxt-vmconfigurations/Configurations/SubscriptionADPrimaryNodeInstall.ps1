param
(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory = $true)]
    [String] $DomainName,

    [Parameter(Mandatory = $true)]
    [String] $DomainNetbiosName,

    [Parameter(Mandatory = $true)]
    [PSCredential] $DomainAdministratorCredentials,

    [Parameter(Mandatory = $true)]
    [String] $AdministratorAccount
)

Configuration SubscriptionAD
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xActiveDirectory
    Import-DscResource -ModuleName NetworkingDsc

    # set $env:temp to a valid folder, to prevent "Could not find a part of the path" error
    $env:temp = "$($env:windir)\temp"

    Node $AllNodes.NodeName
    {
        WindowsFeature DNS
        {
            Ensure    = 'Present'
            Name      = 'DNS'
        }

        WindowsFeature AD-Domain-Services
        {
            Ensure    = 'Present'
            Name      = 'AD-Domain-Services'
        }

        WindowsFeature RSAT-DNS-Server
        {
            Ensure    = 'Present'
            Name      = 'RSAT-DNS-Server'
            DependsOn = '[WindowsFeature]DNS'
        }

        WindowsFeature RSAT-AD-Tools
        {
            Ensure    = 'Present'
            Name      = 'RSAT-AD-Tools'
            DependsOn = '[WindowsFeature]AD-Domain-Services'
        }

        WindowsFeature RSAT-ADDS
        {
            Ensure    = 'Present'
            Name      = 'RSAT-ADDS'
            DependsOn = '[WindowsFeature]AD-Domain-Services'
        }

        WindowsFeature RSAT-ADDS-Tools
        {
            Ensure    = 'Present'
            Name      = 'RSAT-ADDS-Tools'
            DependsOn = '[WindowsFeature]RSAT-ADDS'
        }

        WindowsFeature RSAT-AD-AdminCenter
        {
            Ensure    = 'Present'
            Name      = 'RSAT-AD-AdminCenter'
            DependsOn = '[WindowsFeature]AD-Domain-Services'
        }

        WindowsFeature GPMC
        {
            Ensure    = 'Present'
            Name      = 'GPMC'
            DependsOn = '[WindowsFeature]RSAT-AD-AdminCenter'
        }

        File ADFiles
        {
            Ensure          = 'Present'
            Type            = 'Directory'
            DestinationPath = $Node.DatabasePath
        }

        DnsServerAddress DnsServerAddress
        {
            Address        = '127.0.0.1'
            InterfaceAlias = 'Ethernet'
            AddressFamily  = 'IPv4'
            DependsOn      = "[WindowsFeature]DNS"
        }

        xADDomain PrimaryDC
        {
            DomainName                    = $Node.DomainName
            DomainNetbiosName             = $Node.DomainNetbiosName
            DomainAdministratorCredential = $Node.DomainAdministratorCredentials
            SafemodeAdministratorPassword = $Node.SafeModeAdministratorCredentials
            DatabasePath                  = $Node.DatabasePath
            LogPath                       = $Node.DatabasePath
            DependsOn                     = "[WindowsFeature]AD-Domain-Services","[File]ADFiles"
        }

        xWaitForADDomain WaitForDomain
        {
            DomainName                    = $Node.DomainName
            DomainUserCredential          = $Node.DomainAdministratorCredentials
            RetryCount                    = 6
            RetryIntervalSec              = 60
            RebootRetryCount              = 2
        }

        Script UpdateMaxEnvelopeSizeKb
        {
            PsDscRunAsCredential = $Node.DomainAdministratorCredentials
            SetScript =
            {
                $ErrorActionPreference = "Stop"

                Write-Verbose "Set WinRM MaxEnvelopeSize to 2048KB"
                Set-Item -Path "WSMan:\localhost\MaxEnvelopeSizeKb" -Value 2048
                Write-Verbose "Finished updating MaxEnvelopeSize"
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                # Check if MaxEnvelopeSizeKb is 2048
                return [bool]((Get-Item "WSMan:\localhost\MaxEnvelopeSizeKb").Value -eq 2048)
            }
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                         = $NodeName
            PSDscAllowPlainTextPassword      = $true
            PSDscAllowDomainUser             = $true

            DomainName                       = $DomainName
            DomainNetbiosName                = $DomainNetbiosName
            DomainAdministratorCredentials   = $DomainAdministratorCredentials
            SafeModeAdministratorCredentials = $DomainAdministratorCredentials
            AdministratorAccount             = $AdministratorAccount
            DatabasePath                     = "$($env:SystemDrive)\NTDS"
        }
    )
}

SubscriptionAD -ConfigurationData $ConfigurationData -OutputPath $OutputPath
