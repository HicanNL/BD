param
(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NetbiosDomainName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $SSOServiceAccountCredentials,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $WorkloadInstallerAccountCredential,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $Name,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $WorkloadCode,

    # Node type to determine if it is the First or Additional Server Node
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeType,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $SQLServer,

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [String] $MasterKeyPath = "${Env:SystemDrive}\Data\BizSSO",

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [String] $ConfigurationDataPath = "${Env:SystemDrive}\Configurations\Biz",

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [String] $ConfigurationFile = "SSOConfig.xml",

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [String] $InstallationFile = "BTSInstall.xml",

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [String] $SSOAffiliateAdministratorsGroup = "RESA-$WorkloadCode-$Name-SSOAffiliateAdministrators",

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [String] $SSOAdministratorsGroup = "RESA-$WorkloadCode-$Name-SSOAdministrators"
)

Configuration BizSSO
{
    Import-DscResource -ModuleName xPSDesiredStateConfiguration
    Import-DscResource -ModuleName StorageDsc
    Import-DscResource -ModuleName xSmbShare
    Import-DscResource -ModuleName cInstallSqlServer
    Import-DscResource -ModuleName xCredSSP
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName SqlServerDsc
    Import-DscResource -ModuleName cSSOConfigXML

    Node $AllNodes.NodeName
    {
        File DataFolder
        {
            Type                              = 'Directory'
            DestinationPath                   = $Node.MasterKeyPath
            Ensure                            = 'Present'
        }

        Script BizSSO_PreCheck
        {
            DependsOn                         = '[File]DataFolder'
            PsDscRunAsCredential              = $Node.WorkloadInstallerAccountCredential
            SetScript =
            ({
                $ErrorActionPreference = "Stop"

                if ("{0}" -match "SQLFCI")
                {{
                    # make sure all resources are available on this node
                    Write-Verbose "Making this computer ({1}) the active node"
                    Get-ClusterGroup | Move-ClusterGroup -Node "{1}" | Out-Null

                    # add cluster access rights for the ENTSSO service account
                    Write-Verbose "Granting ENTSSO service account ({2}) access to the cluster"
                    Grant-ClusterAccess -User "{2}" -Full
                }}
            } -f @($Node.NodeType, $env:COMPUTERNAME, $Node.SSOServiceAccountCredential.UserName))
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            ({
                return ("{0}" -notmatch "SQLFCI")
            } -f @($Node.NodeType))
        }

        Script PerfCounters_Reset
        {
            DependsOn                         = "[Script]BizSSO_PreCheck"
            PsDscRunAsCredential              = $Node.WorkloadInstallerAccountCredential
            SetScript =
            {
                Write-Verbose "Resetting performance counters"
                $proc = Start-Process -FilePath "$($env:WINDIR)\system32\lodctr.exe" -ArgumentList "/R" -Wait -PassThru -Verbose
                Write-Verbose "Update performance counters returned: $($proc.ExitCode)"
                $proc = Start-Process -FilePath "$($env:WINDIR)\syswow64\lodctr.exe" -ArgumentList "/R" -Wait -PassThru -Verbose
                Write-Verbose "Update performance counters returned: $($proc.ExitCode)"
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                # Always reset performance counters
                return $false
            }
        }

        Package BizSSO_Install
        {
            DependsOn                         = "[Script]PerfCounters_Reset"
            PsDscRunAsCredential              = $Node.WorkloadInstallerAccountCredential
            Ensure                            = "Present"
            Path                              = "d:\BizTalk Server\Setup.exe"
            Arguments                         = "/CABPATH $($Node.ConfigurationDataPath)\BtsRedistW2K12EN64.cab /S $($Node.ConfigurationDataPath)\$($Node.InstallationFile) /L ${Env:\windir}\logs\BizSSOInstall.log /norestart"
            Name                              = "Microsoft BizTalk Server 2013 R2"
            ProductId                         = "84E4A518-22DE-42F2-8F14-5457EB237C6E"
        }

        Script BizSSO_CUInstall
        {
            SetScript =
            ({
                $arguments  = "/quiet /Log {0}\logs\BizCUInstall.log /norestart"
                $executable = "{1}\KB4038891\Setup.exe"
                Write-Verbose "Triggering BizSSO_CUInstall"
                $proc = Start-Process -FilePath $executable -ArgumentList $arguments -Wait -PassThru -Verbose

                if ($proc.ExitCode -eq 0)
                {{
                    Write-Verbose "Successfully installed BizSSO_CUInstall"
                }}
                elseif (($proc.ExitCode -eq 1641) -or ($proc.ExitCode -eq 3010))
                {{
                    Write-Verbose "Successfully installed BizSSO_CUInstall, but machine must be rebooted"
                    $global:DSCMachineStatus = 1
                }}
                else
                {{
                    $logOutput = Get-Content -Path "{0}\logs\BizCUInstall.log" -ErrorAction SilentlyContinue
                    throw "Failed to install BizSSO_CUInstall with ExitCode: $($proc.ExitCode) and with LogOutput: $($logOutput)"
                }}
            } -f @($env:WINDIR, $Node.ConfigurationDataPath))
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                $cuNameTemplate = 'BizTalk Server 2013 R2 CU|KB4038891'
                $keyResults     = Get-ChildItem -Path HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\ `
                                                -Recurse `
                                                -ErrorAction SilentlyContinue `
                                                | Where { $_.Name -match $cuNameTemplate }
                if ($keyResults.Count -gt 0)
                {
                    Write-Verbose "BizTalk CU installed"
                    return $true
                }

                Write-Verbose "BizTalk CU not installed"
                return $false
            }
        }

        SqlServerLogin Sql_CreateSQLLoginAdminsGroup
        {
            Ensure                            = 'Present'
            Name                              = $Node.SSOAdministratorsGroup
            ServerName                        = $Node.SQLServer
            InstanceName                      = 'MSSQLSERVER'
            LoginType                         = 'WindowsGroup'
        }

        SqlServerRole Sql_AddSytemToAdminRole
        {
            DependsOn                         = "[SqlServerLogin]Sql_CreateSQLLoginAdminsGroup"
            PsDscRunAsCredential              = $Node.WorkloadInstallerAccountCredential
            Ensure                            = 'Present'
            MembersToInclude                  = $Node.SSOAdministratorsGroup
            ServerRoleName                    = 'sysadmin'
            ServerName                        = $Node.SQLServer
            InstanceName                      = 'MSSQLSERVER'
        }

        cSSOConfigXML BizSSO_ConfigXML
        {
            Ensure                            = 'Present'
            DependsOn                         = "[Script]BizSSO_CUInstall"
            Path                              = "$($Node.ConfigurationDataPath)\$($Node.ConfigurationFile)"
            SSOServiceAccount                 = $Node.SSOServiceAccount
            SSOAdministratorsGroup            = $Node.SSOAdministratorsGroup
            SSOAffiliateAdministratorsGroup   = $Node.SSOAffiliateAdministratorsGroup
            MasterKeyPath                     = "$($Node.MasterKeyPath)\Masterkey.bak"
            MasterKey                         = $Node.MasterKey
            MasterKeyReminder                 = $Node.MasterKey
            NetbiosDomainName                 = $Node.NetbiosDomainName
            PlainTextPassword                 = $Node.SSOPassword
            SQLServer                         = $Node.SQLServer
            SSODBName                         = 'SSODB'
            InitialConfig                     = $Node.NodeType
        }

        Script BizSSO_Config
        {
            PsDscRunAsCredential              = $Node.WorkloadInstallerAccountCredential
            DependsOn                         = "[cSSOConfigXML]BizSSO_ConfigXML"
            SetScript =
            ({
                $executable      = "{3}\Microsoft BizTalk Server 2013 R2\Configuration.exe"
                $logFile         = "{0}\logs\BizSSOConfig_$(Get-Date -Format 'hhmmss').log"
                $unconfigureArgs = "/u /noprogressbar"
                $configureArgs   = "/s {1}\{2} /l $logFile /noprogressbar"

                # always run unconfigure first (ignoring the result)
                Write-Verbose "Unconfiguring Biztalk SSO"
                $proc = Start-Process -FilePath $executable -ArgumentList $unconfigureArgs -Wait -PassThru -Verbose
                Write-Verbose "Unconfiguring Biztalk SSO finished with exit code: $($proc.ExitCode)"

                # run configure
                Write-Verbose "Configuring Biztalk SSO"
                $proc = Start-Process -FilePath $executable -ArgumentList $configureArgs -Wait -PassThru -Verbose
                if ($proc.ExitCode -eq 0)
                {{
                    Write-Verbose "Successfully configured Biztalk SSO"
                }}
                elseif (($proc.ExitCode -eq 1641) -or ($proc.ExitCode -eq 3010))
                {{
                    Write-Verbose "Successfully configured Biztalk SSO, but machine must be rebooted"
                    $global:DSCMachineStatus = 1
                }}
                else
                {{
                    $logOutput = Get-Content -Path $logFile -ErrorAction SilentlyContinue
                    throw "Failed to configure Biztalk SSO with ExitCode: $($proc.ExitCode) and LogOutput: $($logOutput)"
                }}
            } -f @($env:WINDIR, $Node.ConfigurationDataPath, $Node.ConfigurationFile, ${env:ProgramFiles(x86)}))
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                $BizTalkInstalled = (Test-Path 'C:\Program Files (x86)\Microsoft BizTalk Server 2013 R2\Configuration.exe')
                if ($BizTalkInstalled)
                {
                    Write-Verbose "BizTalk is installed, retrieving configuration state"
                    $BizTalkConfigured = ((Get-Service -Name "ENTSSO" -ErrorAction SilentlyContinue).Status -eq 'running')
                    if ($BizTalkConfigured)
                    {
                        Write-Verbose "BizTalk SSO is installed and configured"
                        return $true
                    }

                    Write-Verbose "BizTalk SSO is installed but not configured"
                    return $false
                }

                Write-Verbose "BizTalk is not installed"
                return $false
            }
        }

        Script BizSSO_DLL
        {
            PsDscRunAsCredential              = $Node.WorkloadInstallerAccountCredential
            DependsOn                         = "[Script]BizSSO_Config"
            SetScript =
            {
                $ssoPath = (Get-WMIObject -Class Win32_Product | where { $_.Name -eq "Microsoft Enterprise Single Sign-On" }).InstallLocation
                Write-Verbose "Copy 'SSOPSServer.dll' to '$ssoPath'"
                $copy = Copy-Item -Path 'd:\BizTalk Server\Platform\SSO64\Files\SSOPSServer.dll' `
                                  -Destination (Join-Path $ssoPath "SSOPSServer.dll") `
                                  -Force `
                                  -Confirm:$false
                Write-Verbose "Successfully copied 'SSOPSServer.dll' to '$ssoPath'"
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                $ssoPath = (Get-WMIObject -Class Win32_Product | where { $_.Name -eq "Microsoft Enterprise Single Sign-On" }).InstallLocation
                if ((Test-Path $ssoPath) -and !(Test-Path (Join-Path $ssoPath "SSOPSServer.dll")))
                {
                    Write-Verbose "SSO file 'SSOPSServer.dll' isn't present"
                    return $false
                }

                Write-Verbose "SSO file 'SSOPSServer.dll' already present"
                return $true
            }
        }

        Script BizSSO_AutostartService
        {
            DependsOn   = "[Script]BizSSO_Config"
            SetScript   =
            {
                $ErrorActionPreference = "Stop"

                Write-Verbose "Getting Enterprise SSO service"
                $service = Get-Service -Name "ENTSSO"

                Write-Verbose "Configuring service '$($service.Name)'"
                $service | Set-Service -StartupType Automatic
                New-ItemProperty -Path "HKLM:\System\CurrentControlSet\Services\$($service.Name)" `
                                 -Name "DelayedAutostart" `
                                 -Value 1 `
                                 -PropertyType "DWORD" `
                                 -Force
            }
            GetScript =
            {
                Write-Verbose "Getting Enterprise SSO service"
                $service = Get-Service -Name "ENTSSO"

                Write-Verbose "Retrieving service '$($service.Name)' information"
                $delayedAutoStart = Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Services\$($service.Name)" `
                                                     -Name "DelayedAutoStart" `
                                                     -ErrorAction SilentlyContinue
                return @{
                    "Name" = $service.Name
                    "StartMode" = $service.StartType.ToString()
                    "DelayedAutoStart" = $delayedAutoStart
                }
            }
            TestScript =
            {
                Write-Verbose "Getting Enterprise SSO service"
                $service = Get-Service -Name "ENTSSO"

                Write-Verbose "Checking service '$($service.Name)'"
                $delayedAutoStart = Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Services\$($service.Name)" `
                                                     -Name "DelayedAutoStart" `
                                                     -ErrorAction SilentlyContinue
                return (($service.StartMode -eq [System.ServiceProcess.ServiceStartMode]::Automatic) -and ($delayedAutoStart -eq 1))
            }
        }

    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                           = $NodeName
            NodeType                           = $NodeType
            PSDscAllowPlainTextPassword        = $true
            PSDscAllowDomainUser               = $true

            SQLServer                          = $SQLServer
            NetbiosDomainName                  = $NetbiosDomainName
            SSOServiceAccountCredential        = $SSOServiceAccountCredentials
            SSOServiceAccount                  = $SSOServiceAccountCredentials.UserName.Split("\")[1]
            SSOPassword                        = $SSOServiceAccountCredentials.GetNetworkCredential().password
            MasterKeyPath                      = $MasterKeyPath
            MasterKey                          = $SSOServiceAccountCredentials.GetNetworkCredential().password
            ConfigurationDataPath              = $ConfigurationDataPath
            ConfigurationFile                  = $ConfigurationFile
            InstallationFile                   = $InstallationFile
            SSOAdministratorsGroup             = "$NetbiosDomainName\$SSOAdministratorsGroup"
            SSOAffiliateAdministratorsGroup    = "$NetbiosDomainName\$SSOAffiliateAdministratorsGroup"
            WorkloadInstallerAccountCredential = $WorkloadInstallerAccountCredential
        }
    )
}

BizSSO -ConfigurationData $ConfigurationData -OutputPath $OutputPath