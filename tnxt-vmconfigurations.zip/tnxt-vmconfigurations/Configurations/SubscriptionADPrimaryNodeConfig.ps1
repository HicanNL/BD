param
(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory = $true)]
    [String] $ConfigurationsPath,

    [Parameter(Mandatory = $true)]
    [String] $DomainName,

    [Parameter(Mandatory = $true)]
    [PSCredential] $DomainAdministratorCredentials,

    [Parameter(Mandatory = $true)]
    [String] $SubscriptionCode,

    # TimeServers must be a space-delimited list
    [Parameter(Mandatory = $true)]
    [String] $TimeServers,

    [Parameter(Mandatory = $true)]
    [String] $FabricmgmtDomainName,

    [Parameter(Mandatory = $true)]
    [Array] $FabricmgmtDomainControllerIPs,

    [Parameter(Mandatory = $true)]
    [PSCredential] $FabricmgmtAdministratorCredentials,

    [Parameter(Mandatory = $true)]
    [Array] $ForwarderServers,

    [Parameter(Mandatory = $true)]
    [String] $KMSServer,

    [Parameter(Mandatory = $true)]
    [String] $ReverseZone,

    [Parameter(Mandatory = $true)]
    [Array] $OUStructure,

    [Parameter(Mandatory = $true)]
    [Array] $GroupStructure,

    [Parameter(Mandatory = $true)]
    [String] $ADSubnet,

    [Parameter(Mandatory = $true)]
    [String] $SCCMGroupName
)

Configuration SubscriptionAD
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xActiveDirectory
    Import-DscResource -ModuleName NetworkingDsc
    Import-DscResource -ModuleName xDnsServer

    Node $AllNodes.NodeName
    {
        $ErrorActionPreference = "Stop"

        xWaitForADDomain WaitForDomain
        {
            DomainName                    = $Node.DomainName
            DomainUserCredential          = $Node.DomainAdministratorCredentials
            RetryCount                    = 6
            RetryIntervalSec              = 60
            RebootRetryCount              = 2
        }

        xADRecycleBin RecycleBin
        {
            EnterpriseAdministratorCredential = $Node.DomainAdministratorCredentials
            ForestFQDN                        = $Node.DomainName
            DependsOn                         = '[xWaitForADDomain]WaitForDomain'
        }

        xADReplicationSite DefaultSiteName
        {
           Ensure                     = 'Present'
           Name                       = "$($Node.SubscriptionCode)-DefaultSite"
           RenameDefaultFirstSiteName = $true
           DependsOn                  = '[xWaitForADDomain]WaitForDomain'
        }

        Script EnableTimeSynchronization
        {
            PsDscRunAsCredential = $Node.DomainAdministratorCredentials
            SetScript =
            ({
                $ErrorActionPreference = "Stop"

                Write-Verbose "Set time servers to '{0}'"
                $executable = "$env:windir\system32\w32tm.exe"
                $arguments  = "/config /manualpeerlist:`"{0}`" /syncfromflags:manual /reliable:yes /update"
                $proc       = Start-Process -FilePath $executable -ArgumentList $arguments -Wait -PassThru

                if ($proc.ExitCode -eq 0)
                {{
                    Start-Process -FilePath $executable -ArgumentList "/config /update" -Wait
                }}
                Write-Verbose "Successfully set time servers to '{0}'"
            } -f @($Node.TimeServers))
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                # Always set the Time Synchronisation
                return $false
            }
        }

        Script AddConditionalForwarderToFabric
        {
            PsDscRunAsCredential = $Node.DomainAdministratorCredentials
            SetScript =
            {
                $ErrorActionPreference = "Stop"

                Add-DnsServerConditionalForwarderZone -Name $using:Node.FabricmgmtDomainName `
                                                      -MasterServers $using:Node.FabricmgmtDomainControllerIPs `
                                                      -ComputerName $env:COMPUTERNAME `
                                                      -ReplicationScope Forest `
                                                      | Out-Null
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                return ([Bool](Get-DnsServerZone -ComputerName $env:COMPUTERNAME `
                                                 -ErrorAction SilentlyContinue `
                                                 | Where-Object { $_.ZoneType -eq "Forwarder" -and $_.ZoneName -eq $using:Node.FabricmgmtDomainName }))
            }
        }

        xWaitForADDomain WaitForFabricmgmtDomain
        {
            DomainName           = $Node.FabricmgmtDomainName
            DomainUserCredential = $Node.FabricmgmtAdministratorCredentials
            RetryCount           = 6
            RetryIntervalSec     = 30
            DependsOn            = '[Script]AddConditionalForwarderToFabric'
        }

        xADDomainTrust AddDomainTrust
        {
            TargetDomainAdministratorCredential = $Node.FabricmgmtAdministratorCredentials
            TargetDomainName                    = $Node.FabricmgmtDomainName
            TrustType                           = 'Forest'
            TrustDirection                      = 'Bidirectional'
            SourceDomainName                    = $Node.DomainName
            Ensure                              = 'Present'
            DependsOn                           = '[xWaitForADDomain]WaitForFabricmgmtDomain'
        }

        xDnsServerSetting AddDnsServerProperties
        {
            Name               = 'DnsServerSetting'
            DefaultAgingState  = 1
            IsSlave            = $true
            Forwarders         = $Node.ForwarderServers
            MaxCacheTTL        = 30
            RoundRobin         = $true
            LocalNetPriority   = $true
            SecureResponses    = $true
            NoRecursion        = $false
            BindSecondaries    = $false
            StrictFileParsing  = $false
            ScavengingInterval = 168
            LogLevel           = 50393905
        }

        Script AddKmsDnsRecord
        {
            PsDscRunAsCredential = $Node.DomainAdministratorCredentials
            SetScript =
            {
                $ErrorActionPreference = "Stop"
                Add-DnsServerResourceRecord -ZoneName $using:Node.DomainName `
                                            -Weight 0 `
                                            -Priority 0 `
                                            -Port 1688 `
                                            -Name '_vlmcs._tcp' `
                                            -Srv `
                                            -DomainName $using:Node.KMSServer
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                return ([Bool](Get-DnsServerResourceRecord -RRType "Srv" `
                                                           -ZoneName $using:Node.DomainName `
                                                           -ErrorAction SilentlyContinue `
                                                           | Where-Object { $_.Hostname -eq "_vlmcs._tcp" }))
            }
        }

        xDnsServerADZone AddDnsReverseADZone
        {
            Name               = $Node.ReverseZone
            DynamicUpdate      = 'Secure'
            ReplicationScope   = 'Forest'
            Ensure             = 'Present'
        }

        xDnsServerZoneAging AddDnsServerReverseZoneAging
        {
            Name               = $Node.ReverseZone
            Enabled            = $true
            RefreshInterval    = 24
            NoRefreshInterval  = 48
        }

        xDnsServerZoneAging AddDnsServerZoneAging
        {
            Name               = $Node.DomainName
            Enabled            = $true
            RefreshInterval    = 24
            NoRefreshInterval  = 48
        }

        Script UpdateSchemaExtensions
        {
            PsDscRunAsCredential = $Node.DomainAdministratorCredentials
            SetScript =
            {
                $ErrorActionPreference = "Stop"

                Write-Verbose "Updating AD schema extensions"
                $adDomain       = Get-ADDomain -Server $env:COMPUTERNAME
                $adSchemaMaster = (Get-ADForest -Server $adDomain.Forest).SchemaMaster
                $adSchemaNC     = (Get-ADRootDSE).SchemaNamingContext
                $items          = @(
                    @{ "group" = "(A;;LCSWRPWPRC;;;CO)" },
                    @{ "user"  = "(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;CO)" },
                    @{ "computer" = "(A;;LCSWRPWPDTLOCRSDRC;;;CO)" }
                )

                foreach ($item in $items)
                {
                    $itemType  = ($item.Keys | Select-Object -First 1)
                    $itemValue = $item.$itemType

                    # Get existing Security Descriptor for $item from AD Schema.
                    $objContainer = Get-ADObject -Server $adSchemaMaster `
                                                 -Identity "CN=$($itemType),$adSchemaNC" `
                                                 -Properties defaultSecurityDescriptor
                    $securityDescriptor = $objContainer.defaultSecurityDescriptor

                    if ($securityDescriptor -notmatch [Regex]::Escape($itemValue))
                    {
                        $securityDescriptor += $itemValue
                    }

                    try
                    {
                        Write-Verbose "Setting security descriptor for '$itemType' to '$securityDescriptor'"
                        $objContainer | Set-ADObject -Replace @{ "defaultSecurityDescriptor" = $securityDescriptor } `
                                                     -Server $adSchemaMaster
                    }
                    catch
                    {
                        Write-Verbose "Couldn't set security descriptor for '$itemType' to '$securityDescriptor': $($_.Exception.Message)"
                    }
                }

                Write-Verbose "Finished updating AD schema extensions"
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                # Always run, the check is done in the SetScript
                return $false
            }
        }

        foreach ($ou in $Node.OUStructure)
        {
            $name  = $ou.Name
            $path  = $ou.DNPath

            xADOrganizationalUnit "AddOU_$($name)_$path"
            {
                Name       = $name
                Path       = $path
                Ensure     = 'Present'
                Credential = $Node.DomainAdministratorCredentials
            }
        }

        $filter = @("Administrators","DNSAdmins","Cert Publishers")
        $domainDistinguishedName = (Get-ADDomain).DistinguishedName

        foreach ($group in $Node.GroupStructure | Where-Object { ($_.DistinguishedPathName -match $domainDistinguishedName -and $_.GroupName -notin $filter) })
        {
            if (([String]::IsNullOrEmpty($group.Description)))
            {
                $group.Description = "-"
            }
            xADGroup "AddGroup1_$($group.GroupName)"
            {
                GroupName        = $group.GroupName
                Category         = $group.GroupCategory
                GroupScope       = $group.GroupScope
                Path             = $group.DistinguishedPathName
                Description      = $group.Description
                Ensure           = 'Present'
            }
        }

        foreach ($group in $Node.GroupStructure | Where-Object { ($_.DistinguishedPathName -notmatch $domainDistinguishedName -and $_.GroupName -notin $filter) })
        {
            if (([String]::IsNullOrEmpty($group.Description)))
            {
                $group.Description = "-"
            }
            xADGroup "AddGroup2_$($group.GroupName)"
            {
                GroupName        = $group.GroupName
                Category         = $group.GroupCategory
                GroupScope       = $group.GroupScope
                Path             = $group.DistinguishedPathName
                Description      = $group.Description
                DomainController = $Node.FabricmgmtDomainName
                Credential       = $Node.FabricmgmtAdministratorCredentials
                Ensure           = 'Present'
            }
        }

        Script SetOrganizationalUnitPermissions
        {
            PsDscRunAsCredential = $Node.DomainAdministratorCredentials
            SetScript =
            {
                $ErrorActionPreference = "Stop"

                $objRootDSE = Get-ADRootDSE

                $objGUIDMap = @{}
                Get-ADObject -SearchBase ($objRootDSE.SchemaNamingContext) `
                             -LDAPFilter '(schemaidguid=*)' `
                             -Properties LDAPDisplayName,SchemaIDGUID `
                             | ForEach-Object { $objGUIDMap[$_.LDAPDisplayName] = [Guid]$_.SchemaIDGUID }

                $objERMap   = @{}
                Get-ADObject -SearchBase ($objRootDSE.ConfigurationNamingContext) `
                             -LDAPFilter '(&(objectclass=controlAccessRight)(rightsguid=*))' `
                             -Properties DisplayName,RightsGuid `
                             | ForEach-Object { $objERMap[$_.DisplayName] = [Guid]$_.RightsGuid }

                foreach ($obj in $using:Node.OUStructure)
                {
                    $objRoot = $obj.DNPath
                    $OUDN    = "OU=$($obj.Name)"
                    foreach ($ouPermission in $obj.Permissions)
                    {
                        if ($ouPermission.GroupName)
                        {
                            try
                            {
                                if ($ouPermission.ObjectType -eq 'all')
                                {
                                    $objGUID = New-Object -TypeName Guid -ArgumentList '00000000-0000-0000-0000-000000000000'
                                }
                                else
                                {
                                    $objGUID = New-Object -TypeName Guid -ArgumentList $objGUIDMap["$($ouPermission.ObjectType)"]
                                }

                                $objGroup  = Get-ADGroup -Identity $ouPermission.GroupName
                                $objOUDN   = "$OUDN,$($objRoot)"
                                $objACL    = Get-Acl -Path "AD:$objOUDN"
                                $objProps  = $ouPermission.Permission

                                if ($ouPermission.ObjectReverse -eq 'False')
                                {
                                    if ($ouPermission.ExtendedRight)
                                    {
                                        $objExtGUID = New-Object -TypeName Guid -ArgumentList $objERMap["$($ouPermission.ExtendedRight)"]
                                        $objACE = New-Object -TypeName DirectoryServices.ActiveDirectoryAccessRule `
                                                             -ArgumentList $objGroup.SID,
                                                                           $objProps,
                                                                           'Allow',
                                                                           $objExtGUID,
                                                                           $ouPermission.ObjectScope,
                                                                           $objGUID
                                    }
                                    else
                                    {
                                        $objACE = New-Object -TypeName DirectoryServices.ActiveDirectoryAccessRule `
                                                             -ArgumentList $objGroup.SID,
                                                                           $objProps,
                                                                           'Allow',
                                                                           $ouPermission.ObjectScope,
                                                                           $objGUID
                                    }
                                }
                                else
                                {
                                    if ($ouPermission.ExtendedRight)
                                    {
                                        $objExtGUID = New-Object -TypeName Guid -ArgumentList $objERMap["$($ouPermission.ExtendedRight)"]
                                        $objACE = New-Object -TypeName DirectoryServices.ActiveDirectoryAccessRule `
                                                             -ArgumentList $objGroup.SID,
                                                                           $objProps,
                                                                           'Allow',
                                                                           $objExtGUID,
                                                                           $objGUID,
                                                                           $ouPermission.ObjectScope
                                    }
                                    else
                                    {
                                        $objACE = New-Object -TypeName DirectoryServices.ActiveDirectoryAccessRule `
                                                             -ArgumentList $objGroup.SID,
                                                                           $objProps,
                                                                          'Allow',
                                                                           $objGUID,
                                                                           $ouPermission.ObjectScope
                                    }
                                }

                                $objACL.AddAccessRule($objACE)
                                Set-Acl -Path "AD:$objOUDN" -ACLObject $objACL
                            }
                            catch
                            {
                                Write-Verbose "Couldn't set permission for organization unit '$($obj.Name)' with permission '$($ouPermission.GroupName)': $($_.Exception.Message)"
                            }
                        }
                    }
                }
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                # Always run, the check is done in the SetScript
                return $false
            }
        }

        Script EnableOURedirection
        {
            PsDscRunAsCredential = $Node.DomainAdministratorCredentials
            SetScript =
            {
                $ErrorActionPreference = "Stop"

                Write-Verbose "Enabling OU redirection for the computer objects"
                $objRoot    = (Get-ADDomain -Server $env:COMPUTERNAME).DistinguishedName
                $executable = "$env:windir\system32\redircmp.exe"
                $arguments  = "OU=Quarantine,OU=Servers,$objRoot"
                $proc       = Start-Process -FilePath $executable -ArgumentList $arguments -Wait
                Write-Verbose "Finished enabling OU redirection for the computer objects with exit code: $($proc.ExitCode)"
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                return ((Get-ADDomain -Server $env:COMPUTERNAME).ComputersContainer -eq "OU=Quarantine,OU=Servers,$objRoot")
            }
        }

        xADReplicationSubnet AddADSubnetSCCM
        {
            PsDscRunAsCredential = $Node.DomainAdministratorCredentials
            Name                 = $Node.ADSubnet
            Site                 = "$($Node.SubscriptionCode)-DefaultSite"
            Ensure               = 'Present'
        }

        Script CreateAndConfigureSystemManagementContainer
        {
            PsDscRunAsCredential = $Node.DomainAdministratorCredentials
            SetScript            =
            ({
                $ErrorActionPreference = "Stop"

                Write-Verbose "Getting the root of the domain controller information tree"
                $objRootDSE = Get-ADRootDSE | Select-Object -ExpandProperty defaultNamingContext

                $sccmContainer = "CN=System Management,CN=System,$objRootDSE"
                Write-Verbose "Creating system management container '$sccmContainer'"
                New-ADObject -Name 'System Management' `
                             -Type "Container" `
                             -Path "CN=System, $objRootDSE"

                Write-Verbose "Searching for account '{0}'"
                $sccmServersGroupId = Get-ADGroup -Identity '{0}' `
                                                  | Select-Object -ExpandProperty SID

                try
                {{
                    Write-Verbose "Constructing acl permissions for '$sccmContainer'"
                    $acl             = Get-Acl -Path "ad:$sccmContainer"
                    $adPermissions   = [System.DirectoryServices.ActiveDirectoryRights] 'GenericAll'
                    $permissionType  = [System.Security.AccessControl.AccessControlType] 'Allow'
                    $inheritanceType = [System.DirectoryServices.ActiveDirectorySecurityInheritance] 'All'
                    $ace             = New-Object -TypeName System.DirectoryServices.ActiveDirectoryAccessRule `
                                                  -ArgumentList $sccmServersGroupId,
                                                                $adPermissions,
                                                                $permissionType,
                                                                $inheritanceType
                    $acl.AddAccessRule($ace)

                    Write-Verbose "Setting acl permissions on '$sccmContainer' with permission '$adPermissions'"
                    Set-Acl -Path "AD:$sccmContainer" -AclObject $acl
                }}
                catch
                {{
                    Write-Verbose "Couldn't set permission '$adPermissions' for '$sccmContainer': $($_.Exception.Message)"
                }}
            } -f @($Node.SCCMGroupName))
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                # Always run, the container does not exist
                return $false
            }
        }

        Script ExtendADSchemaSCCM
        {
            PsDscRunAsCredential = $Node.DomainAdministratorCredentials
            SetScript =
            {
                $ErrorActionPreference = "Stop"

                Write-Verbose "Extending AD Schema for SCCM"
                try
                {
                    $executable = "d:\SMSSETUP\BIN\I386\extadsch.exe"
                    $proc       = Start-Process -FilePath $executable -Wait

                    $schema     = [DirectoryServices.ActiveDirectory.ActiveDirectorySchema]::GetCurrentSchema()
                    $schema.RefreshSchema()
                    $result     = $schema.FindClass("mSSMSSite")

                    if (!($result))
                    {
                        Write-Verbose "Schema wasn't extended successfully: Check the log at: C:\ExtADSch.log"
                    }
                }
                catch
                {
                    Write-Verbose "Schema wasn't extended successfully: $($_.Exception.Message)"
                }

                Write-Verbose "Finished Extending AD Schema for SCCM"
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                $schema = Get-ADObject -SearchBase ((Get-ADRootDSE).schemaNamingContext) `
                                       -SearchScope OneLevel `
                                       -Filter * `
                                       -Property objectClass, name, whenChanged, whenCreated `
                                       | Select-Object objectClass, name, whenCreated, whenChanged `
                                       | Where-Object { $_.name -like "MS-SMS*" }

                if ($schema)
                {
                    return $true
                }

                return $false
            }
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                           = $NodeName
            PSDscAllowPlainTextPassword        = $true
            PSDscAllowDomainUser               = $true

            ConfigurationsPath                 = $ConfigurationsPath
            DomainName                         = $DomainName
            DomainAdministratorCredentials     = $DomainAdministratorCredentials
            SubscriptionCode                   = $SubscriptionCode
            TimeServers                        = $TimeServers
            FabricmgmtDomainName               = $FabricmgmtDomainName
            FabricmgmtDomainControllerIPs      = $FabricmgmtDomainControllerIPs
            FabricmgmtAdministratorCredentials = $FabricmgmtAdministratorCredentials
            ForwarderServers                   = $ForwarderServers
            KMSServer                          = $KMSServer
            ReverseZone                        = $ReverseZone
            OUStructure                        = $OUStructure
            GroupStructure                     = $GroupStructure
            ADSubnet                           = $ADSubnet
            SCCMGroupName                      = $SCCMGroupName
        }
    )
}

SubscriptionAD -ConfigurationData $ConfigurationData -OutputPath $OutputPath
