param
(
    [Parameter(Mandatory=$true, Position = 0)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true, Position = 1)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true, Position = 2)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true, Position = 3)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles
)

Configuration BootstrapChoco
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node $AllNodes.NodeName
    {
        File OutputPath
        {
            Ensure          = 'Present'
            Type            = 'Directory'
            DestinationPath = 'C:\Windows\System32\Config\systemprofile\AppData\Local\Temp'
        }

        Script InstallcChoco
        {
            GetScript = { @{ Result = (Get-Module -Name cChoco -ListAvailable -ErrorAction SilentlyContinue) } }
            TestScript = {
                return $false
            }
            SetScript = ({
                $url = "{0}"
                $tempZipFile = "$env:TEMP\cChoco.zip"
                Invoke-Webrequest -Uri $url -OutFile $tempZipFile
                Expand-Archive $tempZipFile -DestinationPath "$env:ProgramFiles\WindowsPowerShell\Modules" -Force
                Remove-Item $tempZipFile -Force
            } -f @($Node.ChocoUrl))
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName = $NodeName
            ChocoUrl = "$ChocoFiles/Resources/cChoco.zip"
        }
    )
}

BootstrapChoco -ConfigurationData $ConfigurationData -OutputPath $OutputPath