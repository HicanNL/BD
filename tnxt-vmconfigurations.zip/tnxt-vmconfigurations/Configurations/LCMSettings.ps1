param
(
    [Parameter(Mandatory=$true, Position = 0)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true, Position = 1)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true, Position = 2)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true, Position = 3)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles
)

[DSCLocalConfigurationManager()]
configuration LCMSettings
{
    Node $NodeName
    {
        Settings
        {
            RefreshMode        = "Push"
            ConfigurationMode  = "ApplyOnly"
            ActionAfterReboot  = "StopConfiguration"
            RebootNodeIfNeeded = $false
        }
    }
}

LCMSettings -Output $OutputPath