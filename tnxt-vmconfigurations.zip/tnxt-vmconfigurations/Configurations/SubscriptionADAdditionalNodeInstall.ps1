param
(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory = $true)]
    [String] $DomainName,

    [Parameter(Mandatory = $true)]
    [String] $PrimaryDCIPAddress,

    [Parameter(Mandatory = $true)]
    [PSCredential] $DomainAdministratorCredentials
)

Configuration SubscriptionAD
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xActiveDirectory
    Import-DscResource -ModuleName ComputerManagementDsc
    Import-DscResource -ModuleName NetworkingDsc

    Node $AllNodes.NodeName
    {
        WindowsFeature DNS
        {
            Ensure    = 'Present'
            Name      = 'DNS'
        }

        WindowsFeature AD-Domain-Services
        {
            Ensure    = 'Present'
            Name      = 'AD-Domain-Services'
        }

        WindowsFeature RSAT-DNS-Server
        {
            Ensure    = 'Present'
            Name      = 'RSAT-DNS-Server'
            DependsOn = '[WindowsFeature]DNS'
        }

        WindowsFeature RSAT-AD-Tools
        {
            Ensure    = 'Present'
            Name      = 'RSAT-AD-Tools'
            DependsOn = '[WindowsFeature]AD-Domain-Services'
        }

        WindowsFeature RSAT-ADDS
        {
            Ensure    = 'Present'
            Name      = 'RSAT-ADDS'
            DependsOn = '[WindowsFeature]AD-Domain-Services'
        }

        WindowsFeature RSAT-ADDS-Tools
        {
            Ensure    = 'Present'
            Name      = 'RSAT-ADDS-Tools'
            DependsOn = '[WindowsFeature]RSAT-ADDS'
        }

        WindowsFeature RSAT-AD-AdminCenter
        {
            Ensure    = 'Present'
            Name      = 'RSAT-AD-AdminCenter'
            DependsOn = '[WindowsFeature]AD-Domain-Services'
        }

        WindowsFeature GPMC
        {
            Ensure    = 'Present'
            Name      = 'GPMC'
            DependsOn = '[WindowsFeature]RSAT-AD-AdminCenter'
        }

        File ADFiles
        {
            Ensure          = 'Present'
            Type            = 'Directory'
            DestinationPath = $Node.DatabasePath
        }

        DnsServerAddress DnsServerAddressAdditional
        {
            Address        = @($Node.PrimaryDCIPAddress, '127.0.0.1')
            InterfaceAlias = 'Ethernet'
            AddressFamily  = 'IPv4'
        }

        xWaitForADDomain WaitForPrimaryDC
        {
            DomainName           = $Node.DomainName
            DomainUserCredential = $Node.DomainAdministratorCredentials
            RetryCount           = 6
            RetryIntervalSec     = 30
            RebootRetryCount     = 10
            DependsOn            = '[DnsServerAddress]DnsServerAddressAdditional'
        }

        Computer JoinDomain
        {
            Name       = $env:COMPUTERNAME
            DomainName = $Node.DomainName
            Credential = $Node.DomainAdministratorCredentials
            DependsOn  = '[xWaitForADDomain]WaitForPrimaryDC'
        }

        xADDomainController AdditionalDC
        {
            DomainName                    = $Node.DomainName
            DomainAdministratorCredential = $Node.DomainAdministratorCredentials
            SafemodeAdministratorPassword = $Node.SafeModeAdministratorCredentials
            DatabasePath                  = $Node.DatabasePath
            LogPath                       = $Node.DatabasePath
            DependsOn                     = @("[WindowsFeature]AD-Domain-Services","[Computer]JoinDomain")
        }

        Script UpdateMaxEnvelopeSizeKb
        {
            PsDscRunAsCredential = $Node.DomainAdministratorCredentials
            SetScript =
            {
                $ErrorActionPreference = "Stop"

                Write-Verbose "Set WinRM MaxEnvelopeSize to 2048KB"
                Set-Item -Path "WSMan:\localhost\MaxEnvelopeSizeKb" -Value 2048
                Write-Verbose "Finished updating MaxEnvelopeSize"
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                # Check if MaxEnvelopeSizeKb is 2048
                return [bool]((Get-Item "WSMan:\localhost\MaxEnvelopeSizeKb").Value -eq 2048)
            }
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                         = $NodeName
            PSDscAllowPlainTextPassword      = $true
            PSDscAllowDomainUser             = $true

            DomainName                       = $DomainName
            PrimaryDCIPAddress               = $PrimaryDCIPAddress
            DomainAdministratorCredentials   = $DomainAdministratorCredentials
            SafeModeAdministratorCredentials = $DomainAdministratorCredentials
            DatabasePath                     = "$($env:SystemDrive)\NTDS"
        }
    )
}

SubscriptionAD -ConfigurationData $ConfigurationData -OutputPath $OutputPath
