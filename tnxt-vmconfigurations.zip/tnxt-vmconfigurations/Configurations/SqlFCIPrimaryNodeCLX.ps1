﻿param
(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    # Installer account that invokes the setup
    [Parameter(Mandatory = $true)]
    [PSCredential] $WorkloadInstallerCredential,

    # Node type to determine if it is the First or Additional Server Node
    [Parameter(Mandatory = $true)]
    [String] $NodeType,

    # 3PAR ip address list
    [Parameter(Mandatory = $true)]
    [String] $Locations,

    # Cluster node in datacenter P
    [Parameter(Mandatory = $true)]
    [String] $NodeP,

    # Cluster node in datacenter Q
    [Parameter(Mandatory = $true)]
    [String] $NodeQ,

    # HP Storage serve serialnumber in datacenter P
    [Parameter(Mandatory = $true)]
    [String] $NodeSerP,

    # HP Storage serve serialnumber in datacenter Q
    [Parameter(Mandatory = $true)]
    [String] $NodeSerQ,

    # Replication Group name Primary
    [Parameter(Mandatory = $true)]
    [String] $NodeReplP,

    # Replication Group Name Secondary
    [Parameter(Mandatory = $true)]
    [String] $NodeReplQ,

    # Configurations Path of the CLX installation
    [Parameter(Mandatory = $true)]
    [String] $ConfigurationsPath
)

Configuration SqlFCIPrimaryNodeCLX
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName nHP3PARCLX

    Node $AllNodes.NodeName
    {
        nHP3PARCLXinstall CLX_SilentInstall
        {
            Ensure               = 'Present'
            CLXFilePath          = "$($Node.ConfigurationsPath)\CLXsetup_x64_v4.03.00.exe"
            PsDscRunAsCredential = $Node.WorkloadInstallerCredential
        }

        nHP3PARCLXLic CLX_License
        {
            Ensure               = 'Present'
            CLXFilePath          = $Node.ConfigurationsPath
            DependsOn            = '[nHP3PARCLXinstall]CLX_SilentInstall'
            PsDscRunAsCredential = $Node.WorkloadInstallerCredential
        }

        nHP3PARCLXPwd CLX_PasswordFile
        {
            Ensure               = 'Present'
            CLXFilePath          = $Node.ConfigurationsPath
            PasswordFolder       = $Node.PasswordFolder
            DependsOn            = '[nHP3PARCLXLic]CLX_License'
            PsDscRunAsCredential = $Node.WorkloadInstallerCredential
        }

        nHP3PARCLXAddArrays CLX_AddArrays
        {
            Ensure               = 'Present'
            PasswordFolder       = $Node.PasswordFolder
            Locations            = $Node.Locations
            DependsOn            = '[nHP3PARCLXPwd]CLX_PasswordFile'
            PsDscRunAsCredential = $Node.WorkloadInstallerCredential
        }

        nHP3PARCLXCFG CLX_ArrayConfig
        {
            Ensure               = 'Present'
            NodeP                = $Node.NodeP
            NodeQ                = $Node.NodeQ
            NodeSerP             = $Node.NodeSerP
            NodeSerQ             = $Node.NodeSerQ
            NodeReplP            = $Node.NodeReplP
            NodeReplQ            = $Node.NodeReplQ
            DependsOn            = '[nHP3PARCLXAddArrays]CLX_AddArrays'
            PsDscRunAsCredential = $WorkloadInstallerCredential
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                        = $NodeName
            NodeType                        = $NodeType
            PSDscAllowPlainTextPassword     = $true
            PSDscAllowDomainUser            = $true

            WorkloadInstallerCredential     = $WorkloadInstallerCredential
            Locations                       = $Locations -split ","
            NodeP                           = $NodeP
            NodeQ                           = $NodeQ
            NodeSerP                        = $NodeSerP
            NodeSerQ                        = $NodeSerQ
            NodeReplP                       = $NodeReplP
            NodeReplQ                       = $NodeReplQ
            ConfigurationsPath              = $ConfigurationsPath
            PasswordFolder                  = "$($env:SystemDrive)\HP3PARCLIPassword"
        }
    )
}

SqlFCIPrimaryNodeCLX -ConfigurationData $ConfigurationData -Output $OutputPath