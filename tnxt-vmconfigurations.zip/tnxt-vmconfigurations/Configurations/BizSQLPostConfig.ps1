param
(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $WorkloadInstallerAccountCredential,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $Name,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $WorkloadCode,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $NetbiosDomainName,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $SQLServer,

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [String] $SQLInstanceName = "MSSQLSERVER",

    [Parameter(Mandatory = $false)]
    [String] $ServiceAccountName = "$WorkloadCode-$Name-App",

    [Parameter(Mandatory = $false)]
    [String] $ConfigurationDataPath = "${Env:SystemDrive}\Configurations\BizSQL" # pBTSSQL is extracted to this path
)

Configuration BizSAConfig
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName SqlServerDsc

    Node $AllNodes.NodeName
    {
        SqlServerLogin "add_BizTalkServiceAccount"
        {
            Ensure               = 'Present'
            Name                 = $Node.ServiceAccountName
            LoginType            = 'WindowsUser'
            InstanceName         = $Node.SQLInstanceName
            ServerName           = $Node.SQLServer
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
        }

        SqlDatabaseOwner "BizTalkMgmtDb"
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
            ServerName           = $Node.SQLServer
            Database             = "BizTalkMgmtDb"
            Name                 = $Node.ServiceAccountName
            DependsOn            = "[SqlServerLogin]add_BizTalkServiceAccount"
        }

        SqlDatabaseOwner "BizTalkDTADb"
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
            ServerName           = $Node.SQLServer
            Database             = "BizTalkDTADb"
            Name                 = $Node.ServiceAccountName
            DependsOn            = "[SqlServerLogin]add_BizTalkServiceAccount"
        }

        SqlDatabaseOwner "BizTalkMsgBoxDb"
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
            ServerName           = $Node.SQLServer
            Database             = "BizTalkMsgBoxDb"
            Name                 = $Node.ServiceAccountName
            DependsOn            = "[SqlServerLogin]add_BizTalkServiceAccount"
        }

        SqlDatabaseOwner "SSODB"
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
            ServerName           = $Node.SQLServer
            Database             = "SSODB"
            Name                 = $Node.ServiceAccountName
            DependsOn            = "[SqlServerLogin]add_BizTalkServiceAccount"
        }

        SqlScript "GrantSelectOnSendportHandlers"
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
            ServerInstance       = $Node.SQLServer
            SetFilePath          = "$($Node.ConfigurationDataPath)\GrantSelectOnSendportHandlers\Set.sql"
            TestFilePath         = "$($Node.ConfigurationDataPath)\GrantSelectOnSendportHandlers\Test.sql"
            GetFilePath          = "$($Node.ConfigurationDataPath)\GrantSelectOnSendportHandlers\Get.sql"
            DependsOn            = "[SqlDatabaseOwner]SSODB"
        }

        SqlScript "CreatePurgeJob"
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
            ServerInstance       = $Node.SQLServer
            SetFilePath          = "$($Node.ConfigurationDataPath)\CreatePurgeJob\Set.sql"
            TestFilePath         = "$($Node.ConfigurationDataPath)\CreatePurgeJob\Test.sql"
            GetFilePath          = "$($Node.ConfigurationDataPath)\CreatePurgeJob\Get.sql"
            DependsOn            = "[SqlScript]GrantSelectOnSendportHandlers"
        }

        SqlScript "UpdateJobOwner"
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
            ServerInstance       = $Node.SQLServer
            SetFilePath          = "$($Node.ConfigurationDataPath)\UpdateJobOwner\Set.sql"
            TestFilePath         = "$($Node.ConfigurationDataPath)\UpdateJobOwner\Test.sql"
            GetFilePath          = "$($Node.ConfigurationDataPath)\UpdateJobOwner\Get.sql"
            DependsOn            = "[SqlScript]CreatePurgeJob"
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                           = $NodeName
            PSDscAllowPlainTextPassword        = $true
            PSDscAllowDomainUser               = $true

            WorkloadInstallerAccountCredential = $WorkloadInstallerAccountCredential
            SQLServer                          = $SQLServer
            SQLInstanceName                    = $SQLInstanceName
            ServiceAccountName                 = "$NetbiosDomainName\$ServiceAccountName"
            ConfigurationDataPath              = $ConfigurationDataPath
        }
    )
}

BizSAConfig -ConfigurationData $ConfigurationData -OutputPath $OutputPath
