param
(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory = $true, Position = 1)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory = $true, Position = 2)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory = $true, Position = 3)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles
)

Configuration SubscriptionFSModules
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName cChoco

    Node $AllNodes.NodeName
    {
        # Ensures chocolatey is installed
        cChocoInstaller Default_InstallChocolatey {
            ChocoInstallScriptUrl = $Node.ChocoFiles
            InstallDir            = "c:\Choco"
        }

        # useFipsCompliantChecksums
        Script ChocoEnableFipsCompliantChecksums {
            GetScript  =
            {
                $chocoPath = "C:\Choco\Choco.exe"
                Start-Process -FilePath $chocoPath -ArgumentList "list -lo" -NoNewWindow -Wait
            }
            TestScript =
            {
                $chocoExists = Test-Path "C:\Choco\Choco.exe"
                return (-not ($chocoExists))
            }
            SetScript  =
            {
                $chocoPath = "C:\Choco\Choco.exe"
                $proc = Start-Process -FilePath $chocoPath -ArgumentList "feature enable -n useFipsCompliantChecksums" -PassThru -NoNewWindow -Wait

                if ($proc.ExitCode -eq 0)
                {
                    Write-Verbose "Successfully installed ChocoEnableFipsCompliantChecksums"
                }
                elseif (($proc.ExitCode -eq 1641) -or ($proc.ExitCode -eq 3010))
                {
                    Write-Verbose "Successfully installed ChocoEnableFipsCompliantChecksums, but machine must be rebooted"
                }
                else
                {
                    throw "Failed to install ChocoEnableFipsCompliantChecksums with ExitCode: $($proc.ExitCode)"
                }
            }
        }

        Script ChocoRemoveDefaultSource {
            GetScript  =
            {
                #nothing to do
            }
            TestScript =
            {
                return $false
            }
            SetScript  =
            {
                $chocoPath = "C:\Choco\Choco.exe"
                $proc = Start-Process -FilePath $chocoPath -ArgumentList "source remove -n=chocolatey -f -y" -PassThru -NoNewWindow -Wait

                if ($proc.ExitCode -eq 0)
                {
                    Write-Verbose "Successfully installed ChocoRemoveDefaultSource"
                }
                elseif (($proc.ExitCode -eq 1641) -or ($proc.ExitCode -eq 3010))
                {
                    Write-Verbose "Successfully installed ChocoRemoveDefaultSource, but machine must be rebooted"
                }
                else
                {
                    throw "Failed to install ChocoRemoveDefaultSource with ExitCode: $($proc.ExitCode)"
                }
            }
        }

        cChocoPackageInstaller Install_xPSDesiredStateConfiguration {
            DependsOn = "[cChocoInstaller]Default_InstallChocolatey"
            Ensure    = "Present"
            Name      = "xPSDesiredStateConfiguration"
            Source    = $Node.ChocoSource
        }

        cChocoPackageInstaller Install_xSmbShare {
            DependsOn = "[cChocoInstaller]Default_InstallChocolatey"
            Ensure    = "Present"
            Name      = "xSmbShare"
            Source    = $Node.ChocoSource
        }

        cChocoPackageInstaller Install_xDFS {
            DependsOn = "[cChocoInstaller]Default_InstallChocolatey"
            Ensure    = "Present"
            Name      = "xDFS"
            Source    = $Node.ChocoSource
        }

        cChocoPackageInstaller Install_cNtfsAccessControl {
            DependsOn = "[cChocoInstaller]Default_InstallChocolatey"
            Ensure    = "Present"
            Name      = "cNtfsAccessControl"
            Source    = $Node.ChocoSource
        }

        cChocoPackageInstaller Install_StorageDsc
        {
            DependsOn = "[cChocoInstaller]Default_InstallChocolatey"
            Ensure    = "Present"
            Name      = "StorageDsc"
            Source    = $Node.ChocoSource
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName    = $NodeName
            ChocoSource = "$ChocoSource/nuget"
            ChocoFiles  = $ChocoFiles
        }
    )
}

SubscriptionFSModules -ConfigurationData $ConfigurationData -OutputPath $OutputPath
