param
(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NetbiosDomainName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $WorkloadInstallerAccountCredential
)

Configuration DotNet
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node $AllNodes.NodeName
    {
        WindowsFeature RemoteADAdministrationPowerShellModule
        {
            Ensure = 'Present'
            Name   = 'RSAT-AD-PowerShell'
        }

        WindowsFeature DotNetFramework
        {
            Ensure = 'Present'
            Name   = 'NET-Framework-Core'
        }

        WindowsFeature DotNetFramework45
        {
            Ensure = 'Present'
            Name   = 'NET-Framework-45-Core'
        }

        WindowsFeature NetFramework
        {
            Ensure = 'Present'
            Name   = 'AS-NET-Framework'
        }

        WindowsFeature TCPPortSharing
        {
            Ensure = 'Present'
            Name   = 'AS-TCP-Port-Sharing'
        }

        WindowsFeature WASSupport
        {
            Ensure = 'Present'
            Name   = 'AS-WAS-Support'
        }

        WindowsFeature HTTPActivation
        {
            Ensure = 'Present'
            Name   = 'AS-HTTP-Activation'
        }

        WindowsFeature TCPActivation
        {
            Ensure = 'Present'
            Name   = 'AS-TCP-Activation'
        }

        WindowsFeature NETWCFHTTPActivation45
        {
            Ensure = 'Present'
            Name   = 'NET-WCF-HTTP-Activation45'
        }

        WindowsFeature NETWCFTCPActivation45
        {
            Ensure = 'Present'
            Name   = 'NET-WCF-TCP-Activation45'
        }

        WindowsFeature NETWCFTCPPortSharing45
        {
            Ensure = 'Present'
            Name   = 'NET-WCF-TCP-PortSharing45'
        }

        UserRightsAssignment LogonAsAservice
        {
            Policy               = "log_on_as_a_service"
            Identity             = @(
                                       "$($Node.NetBIOSDomainName)\RESA-AD-LogOnAsAService",
                                       "NT SERVICE\ALL SERVICES",
                                       "$($Node.NetBIOSDomainName)\Workload-ServiceAccounts"
                                   )
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
        }

        UserRightsAssignment LogonAsABatchJob
        {
            Policy               = "log_on_as_a_batch_job"
            Identity             = @(
                                       "$($Node.NetBIOSDomainName)\RESA-AD-LogOnAsBatchJob",
                                       "NT SERVICE\ALL SERVICES",
                                       "$($Node.NetBIOSDomainName)\Workload-ServiceAccounts",
                                       "$($Node.NetBIOSDomainName)\Administrator"
                                   )
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                           = $NodeName
            PSDscAllowPlainTextPassword        = $true
            PSDscAllowDomainUser               = $true

            NetbiosDomainName                  = $NetbiosDomainName
            WorkloadInstallerAccountCredential = $WorkloadInstallerAccountCredential
        }
    )
}

DotNet -ConfigurationData $ConfigurationData -OutputPath $OutputPath
