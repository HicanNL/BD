param
(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory = $true)]
    [String] $DomainName,

    [Parameter(Mandatory = $true)]
    [PSCredential] $DomainAdministratorCredentials,

    [Parameter(Mandatory = $true)]
    [String] $ConfigurationsPath
)

Configuration SubscriptionAD
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xActiveDirectory
    Import-DscResource -ModuleName NetworkingDsc
    Import-DscResource -ModuleName xDnsServer

    Node $AllNodes.NodeName
    {
        $ErrorActionPreference = "Stop"

        xWaitForADDomain WaitForDomain
        {
            DomainName                    = $Node.DomainName
            DomainUserCredential          = $Node.DomainAdministratorCredentials
            RetryCount                    = 6
            RetryIntervalSec              = 60
            RebootRetryCount              = 2
        }

        Script SetGroupPolicies
	    {
		    PsDscRunAsCredential = $Node.DomainAdministratorCredentials
		    SetScript =
		    {
                Write-Verbose "ConfigurationPath: $($using:Node.ConfigurationsPath)"
			    Import-NXTGroupPolicies -TempBackupPath $using:Node.ConfigurationsPath `
									    -GPOSourcePath "$($using:Node.ConfigurationsPath)\GPO" `
									    -ComputerName $env:COMPUTERNAME `
                                        -Verbose
                Write-Verbose "Successfully imported GPOs"
		    }
		    GetScript =
		    {
			    # Do nothing
		    }
		    TestScript =
		    {
                Write-Verbose "ConfigurationPath: $($using:node.ConfigurationsPath)"
                $gpm               = New-Object -ComObject GPMgmt.GPM
			    $constants         = $gpm.getConstants()
			    $gpmBackupDir      = $gpm.GetBackupDir("$($using:Node.ConfigurationsPath)\GPO")
			    $gpmSearchCriteria = $gpm.CreateSearchCriteria()
			    $backupList        = $gpmBackupDir.SearchBackups($gpmSearchCriteria)

			    Write-Verbose "Expected total of $($backupList.Count) imported GPOs"
			    $count = 0
			    foreach ($gpo in $backupList)
			    {
				    try
				    {
                        $resolvedGPO = Get-GPO -Name $gpo.GPODisplayName `
                                               -Server $env:COMPUTERNAME `
                                               -ErrorAction SilentlyContinue
					    if ($resolvedGPO)
					    {
						    Write-Verbose "GPO with displayname found: '$($gpo.GPODisplayName)'"
						    $count++
					    }
				    }
				    catch
				    {
					    Write-Verbose "Group policy import check failed: $($_.Exception.Message)"
				    }
			    }

			    if ($count -ne $backupList.Count)
			    {
			        Write-Verbose "Found $count instead of $($backupList.Count) imported GPOs"
				    return $false
                }

			    Write-Verbose "All group policies are imported"
                return $true
		    }
	    }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                           = $NodeName
            PSDscAllowPlainTextPassword        = $true
            PSDscAllowDomainUser               = $true

            DomainName                         = $DomainName
            DomainAdministratorCredentials     = $DomainAdministratorCredentials
            ConfigurationsPath                 = $ConfigurationsPath
        }
    )
}

SubscriptionAD -ConfigurationData $ConfigurationData -OutputPath $OutputPath
