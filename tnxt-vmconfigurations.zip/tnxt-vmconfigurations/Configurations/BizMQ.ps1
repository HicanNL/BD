<#
    .SYNOPSIS
        Configuration for MQ for BizTalk 2013 R2 VM's.
    .DESCRIPTION
        Configuration for MQ for BizTalk 2013 R2 VM's.
#>

param
(
    [Parameter(Mandatory=$true, Position = 0)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true, Position = 1)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true, Position = 2)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true, Position = 3)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory=$true, Position = 4)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $WorkloadInstallerAccountCredential,

    [Parameter(Mandatory=$false, Position = 5)]
    [ValidateNotNullOrEmpty()]
    [String] $ConfigurationDataPath = "${Env:SystemDrive}\Configurations\BizMQ",

    [Parameter(Mandatory=$false, Position = 6)]
    [ValidateNotNullOrEmpty()]
    [String] $InstallationPath = "${Env:SystemDrive}\Program Files\WebSphere MQ Client 8.0"
)

Configuration BizMQ
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node $AllNodes.NodeName
    {
        Environment MQ_Environment
        {
            Ensure               = "Present"
            Name                 = "MQCCSID"
            Value                = "1208"
        }

        Package MQ_Install
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
            Ensure               = "Present"
            Path                 = "$($Node.ConfigurationDataPath)\mqc_8.0.0.6\Windows\MSI\IBM WebSphere MQ.msi"
            Arguments            = "ADDLOCAL=`"Client`" TRANSFORMS=`"1033.mst`" PGMFOLDER=`"$($Node.InstallationPath)`" AGREETOLICENSE=`"yes`" /quiet"
            Name                 = "IBM WebSphere MQ"
            ProductId            = "0B3A502D-EC2C-46CF-A0E1-42CD11B9938A"
            DependsOn            = "[Environment]MQ_Environment"
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                           = $NodeName
            PSDscAllowPlainTextPassword        = $true
            PSDscAllowDomainUser               = $true
            ConfigurationDataPath              = $ConfigurationDataPath
            WorkloadInstallerAccountCredential = $WorkloadInstallerAccountCredential
        }
    )
}

BizMQ -ConfigurationData $ConfigurationData -OutputPath $OutputPath