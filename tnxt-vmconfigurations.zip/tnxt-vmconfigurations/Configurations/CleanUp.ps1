<#
    .SYNOPSIS
        CleanUp of all Configuration Items.
    .DESCRIPTION
        CleanUp of all Configuration Items.
#>

param
(
    [Parameter(Mandatory=$true, Position = 0)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true, Position = 1)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true, Position = 2)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true, Position = 3)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory=$false, Position = 4)]
    [ValidateNotNullOrEmpty()]
    [String] $ConfigurationDataPath = "${Env:SystemDrive}\Configurations"
)

Configuration CleanUp
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node $AllNodes.NodeName
    {
        File RemoveConfigurations
        {
            Ensure               = "Absent"
            Type                 = "Directory"
            Recurse              = $true
            Force                = $true
            DestinationPath      = $Node.ConfigurationDataPath
        }

        Script DisableDSCEventLogs
        {
            SetScript =
            {
                $eventLogs = @(
                    "Microsoft-Windows-Dsc/Analytic",
                    "Microsoft-Windows-Dsc/Debug"
                )

                foreach ($eventLogName in $eventLogs)
                {
                    try
                    {
                        Write-Verbose "Disabling event log: '$eventLogName'"
                        $eventLog = Get-WinEvent -ListLog $eventLogName
                        $eventLog.IsEnabled = $false
                        $eventLog.SaveChanges()
                        Write-Verbose "Successfully disabled event log: '$eventLogName'"
                    }
                    catch
                    {
                        Write-Verbose "There was an error disabling event log '$eventLogName': $($_.Exception.Message)"
                    }
                }
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                # Do nothing
                return $false
            }
        }

        Service SetWindowsUpdateService
        {
            Name        = "wuauserv"
            StartupType = "Manual"
            State       = "Running"
        }

        Script RemoveChocolatey
        {
            SetScript =
            {
                $chocoInstallDir = [System.Environment]::GetEnvironmentVariable('ChocolateyInstall', 'Machine')
                if ($chocoInstallDir)
                {
                    Write-Verbose "Removing choco environment variable 'ChocolateyInstall' with value '$chocoInstallDir'"
                    [System.Environment]::SetEnvironmentVariable('ChocolateyInstall', $null, 'Machine')
                }

                $pathVariables = [System.Environment]::GetEnvironmentVariable('PATH', 'Machine')
                if ($pathVariables -match 'choco')
                {
                    Write-Verbose "Removing choco environment path from '$pathVariables'"
                    $pathVariables = ($pathVariables.Split(';') | Where-Object { $_ -notlike '*choco*' }) -join ';'
                    [System.Environment]::SetEnvironmentVariable('PATH', $pathVariables, 'Machine')
                }

                if (Test-Path -Path $chocoInstallDir)
                {
                    Write-Verbose "Removing choco installation directory '$chocoInstallDir'"
                    Remove-Item $chocoInstallDir -Confirm:$false -Force -Recurse | Out-Null
                }

                $chocoModuleLocation = "$env:ProgramFiles\WindowsPowerShell\Modules\cChoco"
                if (Test-Path -Path $chocoModuleLocation)
                {
                    "Removing choco installation module '$chocoModuleLocation'"
                    Remove-Item "$chocoModuleLocation" -Confirm:$false -Force -Recurse | Out-Null
                }
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                # Do nothing
                return $false
            }
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                           = $NodeName
            ConfigurationDataPath              = $ConfigurationDataPath
        }
    )
}

CleanUp -ConfigurationData $ConfigurationData -OutputPath $OutputPath