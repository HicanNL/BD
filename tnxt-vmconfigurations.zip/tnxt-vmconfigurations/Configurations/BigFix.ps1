<#
    .SYNOPSIS
        BigFix DSC installation script.
    .DESCRIPTION
        BigFix DSC installation script.
#>

param
(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $WorkloadInstallerAccountCredential,

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [String] $ConfigurationDataPath = "${Env:SystemDrive}\Configurations\BigFix",

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [String] $LogFile = "${Env:SystemDrive}\Temp\BigFix.log"
)

Configuration BigFix
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName NetworkingDsc
    Import-DscResource -ModuleName cChoco

    Node $AllNodes.NodeName
    {
        Firewall Set_FirewallRules
        {
            Ensure      = "Present"
            Name        = "BESCLT"
            DisplayName = "BESCLT"
            Description = "An inbound rule to allow TCP traffic for the BigFix Client [TCP 52311]"
            Direction   = "Inbound"
            Action      = "Allow"
            Enabled     = "True"
            Protocol    = "TCP"
            LocalPort   = "52311"
        }

        Package BigFix_Install
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
            Ensure               = "Present"
            Path                 = "$($Node.ConfigurationDataPath)\BigFixAgent.msi"
            Arguments            = "/passive /l*v `"$($Node.LogFile)`""
            Name                 = "IBM BigFix Client"
            ProductId            = "22D6E6CD-F923-4FEF-85BF-59BD887FBD5F"
            DependsOn            = "[Firewall]Set_FirewallRules"
        }

        Script Copy_ConfigFile
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
            DependsOn            = "[Package]BigFix_Install"
            SetScript =
            {
                $path = (Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -eq "IBM BigFix Client" }).InstallLocation
                $file = "actionsite.afxm"

                Write-Verbose "Copy '$file' to '$path'"
                Copy-Item -Path "$($using:Node.ConfigurationDataPath)\$file" `
                          -Destination $path `
                          -Force `
                          | Out-Null
                Write-Verbose "Successfully copied '$file' to '$path'"
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                $path = (Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -eq "IBM BigFix Client" }).InstallLocation
                $file = "actionsite.afxm"

                if (!(Test-Path (Join-Path $path $file)))
                {
                    Write-Verbose "Config file '$file' isn't present"
                    return $false
                }

                Write-Verbose "Config file '$file' already present"
                return $true
            }
        }

        Script Restart_BigFixService
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
            DependsOn            = "[Script]Copy_ConfigFile"
            SetScript =
            {
                $ErrorActionPreference = "Stop"

                $service = "BESCLIENT"
                Write-Verbose "Restarting service '$service'"
                try
                {
                    Restart-Service $service -Force | Out-Null
                }
                catch
                {
                    throw "Couldn't restart service '$service': $($_.Exception.Message)"
                }
                Write-Verbose "Successfully restarted service '$service'"
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                # Always run
                return $false
            }
        }

        Script Wait_ClientComplete
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
            DependsOn            = "[Script]Restart_BigFixService"
            SetScript =
            {
                $ErrorActionPreference = "Stop"

                $regPath    = "HKLM:\SOFTWARE\Wow6432Node\BigFix\EnterpriseClient\Settings\Client\BCIE_InitialScan"
                $retries    = 0
                $maxRetries = 40
                $complete   = $false

                Write-Verbose "Waiting for the BigFix Client to complete the Initial Scan"
                do
                {
                    try
                    {
                        Get-ItemProperty -Path $regPath | Out-Null
                        $complete = $true
                        Write-Verbose "Initial scan successfully completed"
                    }
                    catch
                    {
                        $retries++

                        if ($retries -le $maxRetries)
                        {
                            Write-Verbose "Initial scan isn't completed yet, registry key not present: retrying [$retries/$maxRetries]"
                            Start-Sleep -Seconds 20
                        }
                    }
                } while (!$complete -and ($retries -le $maxRetries))

                if (!$complete)
                {
                    Write-Verbose "Initial scan couldn't be completed after the maximum time allowed."
                }
            }
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                # Always run
                return $false
            }
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                           = $NodeName
            PSDscAllowPlainTextPassword        = $true
            PSDscAllowDomainUser               = $true
            ConfigurationDataPath              = $ConfigurationDataPath
            LogFile                            = $LogFile
            WorkloadInstallerAccountCredential = $WorkloadInstallerAccountCredential
        }
    )
}

BigFix -ConfigurationData $ConfigurationData -OutputPath $OutputPath