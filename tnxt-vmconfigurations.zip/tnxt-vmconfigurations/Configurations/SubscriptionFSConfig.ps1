param
(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory = $true, Position = 1)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory = $true, Position = 2)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory = $true, Position = 3)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory = $true, Position = 4)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $SubscriptionInstallerAccountCredential,

    [Parameter(Mandatory = $true, Position = 5)]
    [ValidateNotNullOrEmpty()]
    [String] $SubscriptionCode,

    [Parameter(Mandatory = $true, Position = 6)]
    [ValidateNotNullOrEmpty()]
    [String[]] $FileServerFQDNs
)

Configuration SubscriptionFSConfig
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xSmbShare
    Import-DscResource -ModuleName xDFS

    Node $AllNodes.NodeName
    {
        $computerName    = Get-WmiObject -Class Win32_ComputerSystem
        $domain          = $computerName.Domain
        $targetPath      = "$($computerName.Name).$domain"
        $fileShare       = 'FileShare'
        $fileShareFolder = "C:\DFSRoots\$fileShare"
        $path            = "\\$domain\$fileShare"
        $groupName       = "$($Node.SubscriptionCode) Data"
        $dataShare       = 'Data$'
        $dataShareFolder = 'S:\Data'
        $folderName      = 'ReplicaFolder'

        WindowsFeature RSATDFSMgmtConInstall
        {
            Ensure       = 'Present'
            Name         = 'RSAT-DFS-Mgmt-Con'
        }

        xDFSNamespaceServerConfiguration DFSNamespaceConfig
        {
            IsSingleInstance        = 'Yes'
            UseFQDN                 = $true
            PsDscRunAsCredential    = $Node.SubscriptionInstallerAccountCredential
            DependsOn               = '[WindowsFeature]RSATDFSMgmtConInstall'
        }

        xDFSNamespaceRoot DFSNamespaceRoot
        {
            Path                    = $path
            TargetPath              = "\\$targetPath\$fileShare"
            Ensure                  = 'Present'
            Type                    = 'DomainV2'
            PsDscRunAsCredential    = $Node.SubscriptionInstallerAccountCredential
            EnableSiteCosting       = $true
        }

        xDFSReplicationGroup DFSReplicationGroup
        {
            GroupName               = $groupName
            Description             = "$domain replication folder"
            Ensure                  = 'Present'
            DomainName              = $domain
            Folders                 = $folderName
            Members                 = $Node.FileServerFQDNs
            PsDscRunAsCredential    = $Node.SubscriptionInstallerAccountCredential
            DependsOn               = '[xDFSNamespaceRoot]DFSNamespaceRoot'
        }

        xDFSReplicationGroupConnection DFSReplicationGroupConnection1
        {
            GroupName               = $groupName
            Ensure                  = 'Present'
            SourceComputerName      = $Node.FileServerFQDNs[0]
            DestinationComputerName = $Node.FileServerFQDNs[1]
            DomainName              = $domain
            PsDscRunAsCredential    = $Node.SubscriptionInstallerAccountCredential
            DependsOn               = '[xDFSReplicationGroup]DFSReplicationGroup'
        }

        xDFSReplicationGroupConnection DFSReplicationGroupConnection2
        {
            GroupName               = $groupName
            Ensure                  = 'Present'
            SourceComputerName      = $Node.FileServerFQDNs[1]
            DestinationComputerName = $Node.FileServerFQDNs[0]
            DomainName              = $domain
            PsDscRunAsCredential    = $Node.SubscriptionInstallerAccountCredential
            DependsOn               = '[xDFSReplicationGroupConnection]DFSReplicationGroupConnection1'
        }

        xDFSReplicationGroupFolder DFSReplicationGroupFolder
        {
            GroupName               = $groupName
            FolderName              = $folderName
            DomainName              = $domain
            FilenameToExclude       = "~*", "*.bak", "*.tmp"
            PsDscRunAsCredential    = $Node.SubscriptionInstallerAccountCredential
            DependsOn               = '[xDFSReplicationGroupConnection]DFSReplicationGroupConnection2'
        }

        xDFSReplicationGroupMembership DFSReplicationGroupMembership1
        {
            GroupName               = $groupName
            ComputerName            = $Node.FileServerFQDNs[0]
            FolderName              = $folderName
            ContentPath             = $dataShareFolder
            PrimaryMember           = $true
            DomainName              = $domain
            PsDscRunAsCredential    = $Node.SubscriptionInstallerAccountCredential
            DependsOn               = '[xDFSReplicationGroupFolder]DFSReplicationGroupFolder'
        }

        xDFSReplicationGroupMembership DFSReplicationGroupMembership2
        {
            GroupName               = $groupName
            ComputerName            = $Node.FileServerFQDNs[1]
            FolderName              = $folderName
            ContentPath             = $dataShareFolder
            DomainName              = $domain
            PsDscRunAsCredential    = $Node.SubscriptionInstallerAccountCredential
            DependsOn               = '[xDFSReplicationGroupMembership]DFSReplicationGroupMembership1'
        }

        Script DelegatePermissions
        {
            PsDscRunAsCredential    = $Node.SubscriptionInstallerAccountCredential
            DependsOn               = "[xDFSReplicationGroupMembership]DFSReplicationGroupMembership2"
            SetScript =
            ({
                Write-Verbose "Setting permissions on {0}"
                $object = "fabricmgmt\RESA-DFSN-Admins"
                & cmd /c "dfsradmin rg delegate add /account:`"$object`" /rgname:`"{0}`""
                Start-Sleep -Seconds 5
                Set-DFSNRoot -Path "\\{1}\{2}" -GrantAdminAccounts $object
                Write-Verbose "Successfully set permissions on {0}"
            } -f @($groupName, $domain, $fileShare))
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                return $false
            }
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                               = $NodeName
            PSDscAllowPlainTextPassword            = $true
            PSDscAllowDomainUser                   = $true

            SubscriptionInstallerAccountCredential = $SubscriptionInstallerAccountCredential
            SubscriptionCode                       = $SubscriptionCode
            FileServerFQDNs                        = $FileServerFQDNs
        }
    )
}

SubscriptionFSConfig -ConfigurationData $ConfigurationData -OutputPath $OutputPath
