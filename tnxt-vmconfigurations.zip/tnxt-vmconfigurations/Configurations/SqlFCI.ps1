param
(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    # SQL server admins group
    [Parameter(Mandatory = $true)]
    [String] $SqlAdminsGroup,

    # Service account under which the SQL Server wil run
    [Parameter(Mandatory = $true)]
    [PSCredential] $SqlServiceAccountCredential,

    # Installer account that invokes the setup
    [Parameter(Mandatory = $true)]
    [PSCredential] $WorkloadInstallerCredential,

    [Parameter(Mandatory = $true)]
    [String] $SubscriptionDomainFQDN,

    [Parameter(Mandatory = $true)]
    [String] $NetBiosDomainName,

    # Base / stripped name of the Cluster
    [Parameter(Mandatory = $true)]
    [String] $ClusterBase,

    # The cluster network name for the primary cluster group / resource
    [Parameter(Mandatory = $true)]
    [String] $ClusterGroup,

    # The cluster IP-address for the SQL resource
    [Parameter(Mandatory = $true)]
    [String] $SqlClusterIP,

    # The cluster network name for the SQL resource
    [Parameter(Mandatory = $true)]
    [String] $SqlClusterGroup,

    # Node type to determine if it is the first or additional SQL cluster node
    [Parameter(Mandatory = $true)]
    [String] $NodeType,

    # Instance name for SQL Server installation
    [Parameter(Mandatory = $false)]
    [String] $SqlInstanceName = "MSSQLSERVER",

    # Drive letter to use for the SQL log directories
    [Parameter(Mandatory = $false)]
    [String] $SqlLogDriveLetter = "E:",

    # Drive letter to use for the SQL data directories
    [Parameter(Mandatory = $false)]
    [String] $SqlDataDriveLetter = "F:",

    # Drive letter to use for the SQL temp DB directories
    [Parameter(Mandatory = $false)]
    [String] $SqlTempDBDriveLetter = "G:",

    # Drive letter to use for the SQL backup directories
    [Parameter(Mandatory = $false)]
    [String] $SqlBackupDriveLetter = "H:",

    # The SQL Collation
    [Parameter(Mandatory = $false)]
    [String] $SqlCollation = "SQL_Latin1_General_CP1_CI_AS"
)

Configuration SqlFCI
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName NetworkingDsc
    Import-DscResource -ModuleName SqlServerDsc
    Import-DscResource -ModuleName xPSDesiredStateConfiguration
    Import-DscResource -ModuleName StorageDsc
    Import-DscResource -ModuleName xSmbShare
    Import-DscResource -ModuleName cInstallSqlServer
    Import-DscResource -ModuleName xCredSSP
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node $AllNodes.NodeName
    {
        WindowsFeature SqlFCI_RemoteADAdministrationPowerShellModule
        {
            Ensure          = 'Present'
            Name            = 'RSAT-AD-PowerShell'
        }

        WindowsFeature SqlFCI_DotNetFramework
        {
            Ensure          = 'Present'
            Name            = 'NET-Framework-Core'
        }

        WindowsFeature SqlFCI_DotNetFramework45
        {
            Ensure          = 'Present'
            Name            = 'NET-Framework-45-Core'
        }

        WindowsFeature SqlFCI_NetFramework
        {
            Ensure          = 'Present'
            Name            = 'AS-NET-Framework'
        }

        UserRightsAssignment LogonAsAservice
        {
            Policy               = "log_on_as_a_service"
            Identity             = @(
                                       "$($Node.NetBIOSDomainName)\RESA-AD-LogOnAsAService",
                                       "NT SERVICE\ALL SERVICES",
                                       "$($Node.NetBIOSDomainName)\Workload-ServiceAccounts"
                                   )
            PsDscRunAsCredential = $Node.WorkloadInstallerCredential
        }

        UserRightsAssignment LogonAsABatchJob
        {
            Policy               = "log_on_as_a_batch_job"
            Identity             = @(
                                       "$($Node.NetBIOSDomainName)\RESA-AD-LogOnAsBatchJob",
                                       "NT SERVICE\ALL SERVICES",
                                       "$($Node.NetBIOSDomainName)\Workload-ServiceAccounts",
                                       "$($Node.NetBIOSDomainName)\Administrator"
                                   )
            PsDscRunAsCredential = $Node.WorkloadInstallerCredential
        }

        File SqlFCI_SsisShareDirectory
        {
            Ensure          = 'Present'
            Type            = 'Directory'
            DestinationPath = 'C:\SSIS'
        }

        xSmbShare SqlFCI_SsisShare
        {
            DependsOn       = '[File]SqlFCI_SsisShareDirectory'
            Name            = 'SSIS'
            Path            = 'C:\SSIS'
            FullAccess      = 'Everyone'
        }

        Group AdminAccounts
        {
            GroupName        = "Administrators"
            MembersToInclude = @($Node.WorkloadInstallerUser, $Node.SqlServiceAccountUser)
            Ensure           = "Present"
        }

        cInstallSqlFCI SqlFCI_InstallSQLServer
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerCredential
            ProductKey           = $Node.Sql2012ProductKey
            Credential           = $Node.SqlServiceAccountCredential
            InstanceName         = $Node.SqlInstanceName
            ClusterIP            = $Node.SqlClusterIP
            ClusterNetworkName   = $Node.SqlNetworkName
            ClusterGroupName     = $Node.SqlClusterGroup
            LogDrive             = $Node.SqlLogDriveLetter.Trim(":") + ":"
            DataDrive            = $Node.SqlDataDriveLetter.Trim(":") + ":"
            TempDBDrive          = $Node.SqlTempDBDriveLetter.Trim(":") + ":"
            BackupDrive          = $Node.SqlBackupDriveLetter.Trim(":") + ":"
            Collation            = $Node.SqlCollation
            JoinCluster          = $Node.JoinCluster
        }

        Firewall SqlFCI_SqlServerPortFirewallRule
        {
            DependsOn   = "[cInstallSqlFCI]SqlFCI_InstallSQLServer"
            Ensure      = "Present"
            Name        = "Microsoft Sql Server (port)"
            DisplayName = "Microsoft Sql Server (port)"
            Description = "An inbound rule to allow TCP traffic for SQL Server [TCP 1433]"
            Enabled     = "True"
            Protocol    = "TCP"
            LocalPort   = "1433"
        }

        Firewall SqlFCI_SqlServerFirewallRule
        {
            DependsOn   = "[cInstallSqlFCI]SqlFCI_InstallSQLServer"
            Ensure      = "Present"
            Name        = "Microsoft Sql Server (application)"
            DisplayName = "Microsoft Sql Server (application)"
            Description = "An inbound rule to allow traffic for SQL Server [sqlservr.exe]"
            Enabled     = "True"
            Program     = "${Env:ProgramW6432}\Microsoft SQL Server\MSSQL11.$($Node.SqlInstanceName)\MSSQL\binn\sqlservr.exe"
        }
    }

    Node $AllNodes.Where{$_.NodeType -eq 'SQLFCIPrimary'}.NodeName
    {
        SqlServerLogin SqlFCI_CreateSQLLoginAdminsGroup
        {
            DependsOn        = "[cInstallSqlFCI]SqlFCI_InstallSQLServer"
            Ensure           = 'Present'
            Name             = $Node.SqlAdminsGroup
            ServerName       = $Node.SqlNetworkName
            InstanceName     = $Node.SqlInstanceName
            LoginType        = 'WindowsGroup'
        }

        SqlServerRole SqlFCI_AddAdminsToAdminRole
        {
            DependsOn        = "[cInstallSqlFCI]SqlFCI_InstallSQLServer", "[SqlServerLogin]SqlFCI_CreateSQLLoginAdminsGroup"
            Ensure           = 'Present'
            MembersToInclude = @($Node.SqlAdminsGroup, "NT AUTHORITY\SYSTEM")
            ServerRoleName   = "sysadmin"
            ServerName       = $Node.SqlNetworkName
            InstanceName     = $Node.SqlInstanceName
        }

        cConfigureAutogrow SqlFCI_ConfigureAutogrowMaster
        {
            DependsOn        = "[cInstallSqlFCI]SqlFCI_InstallSQLServer"
            InstanceName     = $Node.SqlInstanceName
            DatabaseName     = 'Master'
            SQLServer        = $Node.SqlNetworkName
            LogInitialSize   = 32768
            LogGrowthType    = 'KB'
            LogGrowth        = 32768
            DataInitialSize  = 65536
            DataGrowthType   = 'KB'
            DataGrowth       = 65536
        }

        cConfigureAutogrow SqlFCI_ConfigureAutogrowModel
        {
            DependsOn        = "[cConfigureAutogrow]SqlFCI_ConfigureAutogrowMaster"
            InstanceName     = $Node.SqlInstanceName
            DatabaseName     = 'Model'
            SQLServer        = $Node.SqlNetworkName
            LogInitialSize   = 32768
            LogGrowthType    = 'KB'
            LogGrowth        = 32768
            DataInitialSize  = 65536
            DataGrowthType   = 'KB'
            DataGrowth       = 65536
        }

        cMaintenanceJobs SqlFCI_MaintenanceJobs
        {
            DependsOn    = "[cConfigureAutogrow]SqlFCI_ConfigureAutogrowModel"
            InstanceName = $Node.SqlInstanceName
            SQLServer    = $Node.SqlNetworkName
        }

        cTempDbFiles SqlFCI_TempDbFiles
        {
            DependsOn    = "[cConfigureAutogrow]SqlFCI_ConfigureAutogrowModel"
            InstanceName = $Node.SqlInstanceName
            SQLServer    = $Node.SqlNetworkName
        }
    }

    Node $AllNodes.Where{$_.NodeType -eq 'SQLFCISecondary'}.NodeName
    {
        Script CreateDependencies
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerCredential
            SetScript =
            ({
                $ErrorActionPreference = "Stop"

                Write-Verbose "Moving resources from '{0}' to '{1}'"
                Stop-ClusterGroup -Name "{0}" -ErrorAction SilentlyContinue
                Stop-ClusterGroup -Name "{1}"
                Get-ClusterResource `
                    | Where-Object {{ $_.OwnerGroup -eq "{0}" }} `
                    | Move-ClusterResource -Group "{1}"

                Write-Verbose "Creating dependencies for the 'Cluster Extension 3PAR Group'"
                $disks = @(
                    Get-ClusterResource `
                        | Where-Object {{ $_.OwnerGroup -eq "{1}" }} `
                        | Where-Object {{ $_.ResourceType -eq "Physical Disk" }}
                )

                foreach ($disk in $disks)
                {{
                    # add CLX Dependencies if non-existing
                    $dependency = Get-ClusterResourceDependency -Resource $disk.Name -ErrorAction SilentlyContinue
                    if (!$dependency -or !$dependency.DependencyExpression)
                    {{
                        Write-Verbose "Adding dependency on '$($disk.Name)'"
                        Add-ClusterResourceDependency -Resource $disk.name `
                                                      -Provider "Cluster Extension 3PAR" `
                                                      | Out-Null
                    }}
                }}

                Write-Verbose "Removing resource group '{0}'"
                Remove-ClusterGroup -Name "{0}" -Force -ErrorAction SilentlyContinue

                $clusterGroup = Start-ClusterGroup -Name "{1}"
                if ($clusterGroup.State -ne [Microsoft.FailoverClusters.PowerShell.ClusterGroupState]::Online)
                {{
                    throw "Failed to bring cluster group {1} online"
                }}

                Write-Verbose "Successfully created dependencies"
            } -f @($Node.ClusterGroup, $Node.SQLClusterGroup))
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            ({
                Write-Verbose "Checking resource group '{0}'"
                if (Get-ClusterGroup -Name "{0}" -ErrorAction SilentlyContinue -Verbose:$false)
                {{
                    Write-Verbose "Resource group '{0}' still exists"
                    return $false
                }}

                Write-Verbose "Checking resource group '{1}'"
                if (!(Get-ClusterGroup -Name "{1}" -ErrorAction SilentlyContinue -Verbose:$false))
                {{
                    Write-Verbose "Resource group '{1}' does not exist"
                    return $false
                }}

                Write-Verbose "Checking disks"
                $allDisks = @(
                    Get-ClusterResource `
                        | Where-Object {{ $_.ResourceType -eq "Physical Disk" }}
                )
                $disks = @(
                    $allDisks | Where-Object {{ $_.OwnerGroup -eq "{1}" }} `
                )
                if ($allDisks.Count -ne $disks.Count)
                {{
                    Write-Verbose "Not all disks are added to the resource group '{1}'"
                    return $false
                }}

                Write-Verbose "Checking dependencies"
                $dependencyCheck = $true
                foreach ($disk in $disks)
                {{
                    $dependency = Get-ClusterResourceDependency -Resource $disk.Name -ErrorAction SilentlyContinue
                    if (!$dependency -or !$dependency.DependencyExpression)
                    {{
                        Write-Verbose "Disk '$($disk.Name)' is missing a dependency"
                        $dependencyCheck = $false
                    }}
                }}

                return $dependencyCheck
            } -f @($Node.ClusterGroup, $Node.SQLClusterGroup))
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                    = $NodeName
            NodeType                    = $NodeType
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser        = $true

            Sql2012ProductKey           = "FH666-Y346V-7XFQ3-V69JM-RHW28"
            SqlServiceAccountCredential = $SqlServiceAccountCredential
            SqlServiceAccountUser       = $SqlServiceAccountCredential.UserName
            SqlInstanceName             = $SqlInstanceName
            SqlAdminsGroup              = $SqlAdminsGroup
            SqlCollation                = $SqlCollation
            SqlLogDriveLetter           = $SqlLogDriveLetter
            SqlDataDriveLetter          = $SqlDataDriveLetter
            SqlTempDBDriveLetter        = $SqlTempDBDriveLetter
            SqlBackupDriveLetter        = $SqlBackupDriveLetter
            ClusterGroup                = $ClusterGroup
            SqlNetworkName              = "$($ClusterBase)S"
            SqlClusterGroup             = $SqlClusterGroup
            SqlClusterIP                = $SqlClusterIP
            JoinCluster                 = $NodeType -ne "SQLFCIPrimary"

            WorkloadInstallerCredential = $WorkloadInstallerCredential
            WorkloadInstallerUser       = $WorkloadInstallerCredential.UserName
            SubscriptionDomainFQDN      = $SubscriptionDomainFQDN
            NetBIOSDomainName           = $NetBiosDomainName
        }
    )
}

SqlFCI -ConfigurationData $ConfigurationData -Output $OutputPath