param
(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [PSCredential] $WorkloadInstallerAccountCredential,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $SiteCode,
    
    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [String] $ConfigurationDataPath = "${Env:SystemDrive}\Configurations\SCCMAgent",

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [String] $LogFile = "${Env:SystemDrive}\Temp\SCCMAgent.log"
)

Configuration SCCMAgentInstall
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName cChoco

    Node $AllNodes.NodeName
    {
        Script SCCMAgent_Install
        {
            PsDscRunAsCredential = $Node.WorkloadInstallerAccountCredential
            SetScript =
            ({
                $ErrorActionPreference = "Stop"
                $exePath               = "{0}\ccmsetup.exe"
                $arguments             = "/skipprereq:silverlight.exe SMSSITECODE='{1}'"
                Write-Verbose "Start SCCM agent installation"
                $proc = Start-Process -FilePath $exePath -ArgumentList $arguments -Wait -PassThru -Verbose

                if ($proc.ExitCode -eq 0)
                {{
                    Write-Verbose "Successfully installed SCCM agent"
                }}
                else
                {{
                    throw "Failed to install SCCM agent with ExitCode: $($proc.ExitCode)"
                }}
            } -f @($Node.ConfigurationDataPath, $Node.SiteCode))
            GetScript =
            {
                # Do nothing
            }
            TestScript =
            {
                $ErrorActionPreference = "Stop"

                try 
                {
                    $service = Get-Service -Name "CcmExec"
                    return $true
                }
                catch 
                {
                    return $false
                }
            }
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                           = $NodeName
            PSDscAllowPlainTextPassword        = $true
            PSDscAllowDomainUser               = $true
            ConfigurationDataPath              = $ConfigurationDataPath
            WorkloadInstallerAccountCredential = $WorkloadInstallerAccountCredential
            SiteCode                           = $SiteCode
        }
    )
}

SCCMAgentInstall -ConfigurationData $ConfigurationData -OutputPath $OutputPath