﻿param
(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $NodeName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $OutputPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoSource,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String] $ChocoFiles,

    # Installer account that invokes the setup
    [Parameter(Mandatory = $true)]
    [PSCredential] $WorkloadInstallerCredential,

    # Base / stripped name of the Cluster
    [Parameter(Mandatory = $true)]
    [String] $ClusterBase,

    # IPAddress of the Cluster
    [Parameter(Mandatory = $true)]
    [String] $ClusterIPAddress,

    # Node type to determine if it is the First or Additional Server Node
    [Parameter(Mandatory = $true)]
    [String] $NodeType
)

Configuration SqlFCISecondaryNodeConfig
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xFailOverCluster
    Import-DscResource -ModuleName cMSDTC
    Import-DscResource -ModuleName nHP3PARCLX

    Node $AllNodes.NodeName
    {
        xWaitForCluster WaitForCluster
        {
            Name                          = $Node.ClusterName
            RetryIntervalSec              = 10
            RetryCount                    = 60
        }

        xCluster JoinSecondNodeToCluster
        {
            Name                          = $Node.ClusterName
            StaticIPAddress               = $Node.ClusterIPAddress
            DomainAdministratorCredential = $Node.WorkloadInstallerCredential
            DependsOn                     = '[xWaitForCluster]WaitForCluster'
        }

        Registry ClusterDelayedAutostart
        {
            Ensure                        = "Present"
            Key                           = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\ClusSvc"
            ValueName                     = "DelayedAutostart"
            ValueType                     = "DWORD"
            ValueData                     = 1
        }

        cMSDTC ConfigureMsDtcLocal
        {
            Ensure                            = 'Present'
            Name                              = 'Local'
            InboundTransactionsEnabled        = 1
            OutboundTransactionsEnabled       = 1
            RemoteClientAccessEnabled         = 1
            RemoteAdministrationAccessEnabled = 1
            AuthenticationLevel               = 'Mutual'
            LUTransactionsEnabled             = 1
            XATransactionsEnabled             = 0
        }

        cMSDTC ConfigureMsDtcCluster
        {
            Ensure                            = 'Present'
            PsDscRunAsCredential              = $Node.WorkloadInstallerCredential
            Name                              = $Node.ClusterResourceNameDTC
            InboundTransactionsEnabled        = 1
            OutboundTransactionsEnabled       = 1
            RemoteClientAccessEnabled         = 1
            RemoteAdministrationAccessEnabled = 1
            AuthenticationLevel               = 'Mutual'
            LUTransactionsEnabled             = 1
            XATransactionsEnabled             = 0
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                        = $NodeName
            NodeType                        = $NodeType
            PSDscAllowPlainTextPassword     = $true
            PSDscAllowDomainUser            = $true

            WorkloadInstallerCredential     = $WorkloadInstallerCredential
            ClusterName                     = "$($ClusterBase)C"
            ClusterIPAddress                = $ClusterIPAddress
            ClusterResourceNameDTC          = "MSDTC-Cluster"
        }
    )
}

SqlFCISecondaryNodeConfig -ConfigurationData $ConfigurationData -Output $OutputPath